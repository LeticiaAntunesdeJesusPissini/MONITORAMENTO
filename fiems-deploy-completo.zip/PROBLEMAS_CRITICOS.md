# PROBLEMAS CRÍTICOS IDENTIFICADOS

## 1. Dados Simulados (CRÍTICO - BLOQUEADOR)
- [ ] Verificar se há dados simulados no banco
- [ ] Identificar origem de todos os dados
- [ ] Remover qualquer dado que não seja real
- [ ] Garantir 100% de dados reais dos portais oficiais

## 2. Informações Essenciais Faltando
- [ ] Número da proposição não está aparecendo
- [ ] Link para publicação original não funciona
- [ ] Métricas incorretas ou fantasiosas

## 3. Funcionalidades Pendentes
- [ ] Criar página de detalhes de proposição
- [ ] Implementar filtros completos (setor, impacto, data)
- [ ] Mostrar histórico de tramitação (20 etapas)
- [ ] Exibir número da proposição corretamente
- [ ] Link direto para a publicação oficial

## 4. Problemas de Interface
- [ ] Verificar se todas as informações estão sendo exibidas
- [ ] Corrigir layout de cards
- [ ] Adicionar links funcionais
