# Plano de Reconstrução do Sistema de Monitoramento Legislativo FIEMS

## Fase 1: Limpeza do Banco de Dados
- [ ] Deletar TODOS os dados simulados da tabela de proposições
- [ ] Deletar TODOS os dados simulados da tabela de atos
- [ ] Deletar alertas fictícios
- [ ] Verificar que banco está completamente limpo

## Fase 2: Reconfiguração dos Coletores
- [ ] Adicionar delays naturais (3-8 segundos entre ações)
- [ ] Implementar rotação de user agents
- [ ] Adicionar tratamento robusto de erros
- [ ] Implementar validação rigorosa de dados coletados
- [ ] Garantir que APENAS dados reais sejam salvos

## Fase 3: Coleta de Dados Reais
- [ ] Executar coletor ALEMS com validação
- [ ] Verificar manualmente 5 proposições coletadas
- [ ] Executar coletor DOE/MS com validação
- [ ] Verificar manualmente 5 atos coletados
- [ ] Confirmar que TODOS os dados têm fonte real

## Fase 4: Implementação de Funcionalidades Pendentes
- [ ] Criar página de detalhes de proposição
- [ ] Implementar histórico de tramitação (20 etapas)
- [ ] Adicionar filtros funcionais completos
- [ ] Exibir número da proposição corretamente
- [ ] Adicionar links para publicações originais
- [ ] Corrigir exibição de métricas

## Fase 5: Testes e Validação
- [ ] Testar cada página individualmente
- [ ] Verificar que não há dados simulados
- [ ] Testar todos os filtros
- [ ] Verificar links para fontes originais
- [ ] Testar responsividade
- [ ] Verificar performance

## Fase 6: Documentação
- [ ] Documentar estrutura do banco
- [ ] Documentar coletores
- [ ] Criar manual do usuário
- [ ] Criar guia de manutenção para GETIN
