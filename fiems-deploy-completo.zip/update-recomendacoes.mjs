import { createClient } from '@supabase/supabase-js';
import fs from 'fs';

const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://iqjxqvxlqcbxgbkpbwhe.supabase.co';
const supabaseKey = process.env.SUPABASE_KEY || process.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseKey) {
  console.error('❌ SUPABASE_KEY não configurada');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

// Carregar recomendações
const recomendacoes = JSON.parse(fs.readFileSync('/home/ubuntu/recomendacoes_atos.json', 'utf-8'));

// Mapeamento de números de atos
const atosNumeros = {
  "Decreto 16691": "16691",
  "Decreto 16690": "16690",
  "Decreto 16689": "16689",
  "Lei Complementar 351": "351",
  "Decreto O 099": "099",
  "Ato Declaratório SAT 380": "380"
};

async function atualizarRecomendacoes() {
  console.log('🔄 Iniciando atualização de recomendações...\n');
  
  for (const rec of recomendacoes) {
    const atoNome = rec.ato.split(' - ')[0];
    const numero = atosNumeros[atoNome];
    
    console.log(`📝 Processando: ${rec.ato}`);
    
    // Buscar ID do ato
    const { data: atos, error: atoError } = await supabase
      .from('atos_executivo_2025_11_05_16_31')
      .select('id')
      .eq('numero', numero)
      .eq('ano', '2025')
      .limit(1);
    
    if (atoError) {
      console.error(`   ❌ Erro ao buscar ato: ${atoError.message}`);
      continue;
    }
    
    if (!atos || atos.length === 0) {
      console.log(`   ⚠️  Ato não encontrado no banco`);
      continue;
    }
    
    const atoId = atos[0].id;
    console.log(`   ✓ ID do ato: ${atoId}`);
    
    // Atualizar análise
    const { error: updateError } = await supabase
      .from('analises_atos_executivo_2025_11_10')
      .update({ recomendacao_acao: rec.recomendacao_acao })
      .eq('ato_executivo_id', atoId);
    
    if (updateError) {
      console.error(`   ❌ Erro ao atualizar: ${updateError.message}`);
    } else {
      console.log(`   ✅ Recomendação atualizada com sucesso\n`);
    }
  }
  
  console.log('✅ Atualização concluída!');
}

atualizarRecomendacoes().catch(console.error);
