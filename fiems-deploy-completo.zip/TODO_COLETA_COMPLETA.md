# TODO - Coleta Completa de Dados (06/11/2025)

## 🎯 OBJETIVO
Coletar TODOS os dados de 03-06/11/2025 com informações completas e corretas

## 📋 TAREFAS

### Fase 1: Extração de Proposições
- [ ] Extrair todas as 56 proposições do SGPL (03-06/11/2025)
- [ ] Coletar números corretos de cada proposição
- [ ] Extrair ementas completas
- [ ] Extrair autores e coautores
- [ ] Extrair informações de tramitação
- [ ] Salvar dados em formato estruturado (JSON)

### Fase 2: Coleta de Atos
- [ ] Baixar DOE/MS de 03/11/2025
- [ ] Baixar DOE/MS de 04/11/2025
- [ ] Baixar DOE/MS de 05/11/2025 (já feito)
- [ ] Baixar DOE/MS de 06/11/2025 (já feito)
- [ ] Extrair todos os decretos relevantes
- [ ] Extrair portarias com impacto tributário/fiscal
- [ ] Salvar dados em formato estruturado (JSON)

### Fase 3: Atualização do Banco
- [ ] Limpar tabela de proposições antigas
- [ ] Inserir 56 proposições novas com números corretos
- [ ] Limpar tabela de atos antigos
- [ ] Inserir atos de novembro com dados completos
- [ ] Verificar integridade dos dados

### Fase 4: Análises de Impacto
- [ ] Gerar análises para 56 proposições
- [ ] Gerar análises para atos de novembro
- [ ] Inserir análises na tabela analises_impacto
- [ ] Verificar qualidade das análises

### Fase 5: Melhorias de Interface
- [ ] Adicionar campo "resumo_executivo" visível nos cards
- [ ] Reorganizar layout para mostrar análise sem rolar
- [ ] Garantir que números apareçam corretamente
- [ ] Adicionar indicadores visuais de novos documentos

### Fase 6: Testes
- [ ] Verificar Dashboard (contadores corretos)
- [ ] Verificar lista de Proposições (56+ itens)
- [ ] Verificar lista de Atos (27+ itens)
- [ ] Verificar páginas individuais (análises visíveis)
- [ ] Verificar Alertas (contagem correta)

### Fase 7: Documentação
- [ ] Criar relatório de coleta
- [ ] Documentar fontes de dados
- [ ] Salvar checkpoint final
- [ ] Preparar apresentação para Assessoria
