#!/usr/bin/env python3
"""
Script ROBUSTO v2 para coletar proposições do SGPL
Com tratamento de erros e fallbacks
"""

import json
import time
from playwright.sync_api import sync_playwright

def coletar_proposicoes_sgpl():
    """
    Coleta proposições usando abordagem mais robusta
    """
    proposicoes = []
    
    with sync_playwright() as p:
        print("🚀 Iniciando navegador...")
        browser = p.chromium.launch(headless=True, args=['--no-sandbox'])
        context = browser.new_context(viewport={'width': 1920, 'height': 1080})
        page = context.new_page()
        
        # Aumentar timeout padrão
        page.set_default_timeout(60000)
        
        try:
            # Acessar SGPL
            print("📡 Acessando SGPL...")
            page.goto("https://sgpl.consulta.al.ms.gov.br/sgpl-publico/", 
                     wait_until="domcontentloaded")
            
            print("⏳ Aguardando carregamento completo...")
            time.sleep(5)
            
            # Tirar screenshot para debug
            page.screenshot(path="/home/ubuntu/sgpl_inicial.png")
            print("📸 Screenshot salvo: /home/ubuntu/sgpl_inicial.png")
            
            # Tentar encontrar a aba de Pesquisa Avançada
            print("🔍 Procurando aba Pesquisa Avançada...")
            
            # Tentar vários seletores possíveis
            selectors = [
                "a:has-text('Pesquisa Avançada')",
                "li:has-text('Pesquisa Avançada') a",
                "[href*='avancada']",
                "text=Pesquisa Avançada"
            ]
            
            clicked = False
            for selector in selectors:
                try:
                    element = page.wait_for_selector(selector, timeout=10000)
                    if element:
                        print(f"✅ Encontrado com seletor: {selector}")
                        element.click()
                        clicked = True
                        break
                except:
                    continue
            
            if not clicked:
                print("⚠️  Não conseguiu clicar em Pesquisa Avançada, tentando abordagem alternativa...")
                # Tentar usar JavaScript
                page.evaluate("""
                    const links = Array.from(document.querySelectorAll('a'));
                    const link = links.find(a => a.textContent.includes('Pesquisa Avançada'));
                    if (link) link.click();
                """)
            
            time.sleep(3)
            page.screenshot(path="/home/ubuntu/sgpl_avancada.png")
            print("📸 Screenshot salvo: /home/ubuntu/sgpl_avancada.png")
            
            # Preencher datas usando JavaScript (mais confiável)
            print("📅 Preenchendo datas com JavaScript...")
            page.evaluate("""
                const inputs = document.querySelectorAll('input[type="text"]');
                let dataInicio = null;
                let dataFim = null;
                
                // Procurar campos de data (geralmente vazios ou com placeholder vazio)
                for (let input of inputs) {
                    const label = input.closest('div')?.querySelector('label')?.textContent || '';
                    if (label.includes('Data') || input.placeholder === '') {
                        if (!dataInicio) {
                            dataInicio = input;
                        } else if (!dataFim) {
                            dataFim = input;
                        }
                    }
                }
                
                if (dataInicio) {
                    dataInicio.value = '03/11/2025';
                    dataInicio.dispatchEvent(new Event('input', { bubbles: true }));
                    dataInicio.dispatchEvent(new Event('change', { bubbles: true }));
                }
                
                if (dataFim) {
                    dataFim.value = '06/11/2025';
                    dataFim.dispatchEvent(new Event('input', { bubbles: true }));
                    dataFim.dispatchEvent(new Event('change', { bubbles: true }));
                }
            """)
            
            time.sleep(2)
            
            # Clicar em Pesquisar
            print("🔎 Clicando em Pesquisar...")
            page.click("button:has-text('Pesquisar')")
            
            print("⏳ Aguardando resultados...")
            time.sleep(8)
            
            page.screenshot(path="/home/ubuntu/sgpl_resultados.png")
            print("📸 Screenshot salvo: /home/ubuntu/sgpl_resultados.png")
            
            # Extrair dados da tabela
            print("📊 Extraindo dados...")
            
            pagina = 1
            while True:
                print(f"\n📄 Processando página {pagina}...")
                
                # Aguardar tabela carregar
                page.wait_for_selector("table tbody tr", timeout=30000)
                
                # Extrair dados usando JavaScript
                dados_pagina = page.evaluate("""
                    () => {
                        const linhas = document.querySelectorAll('table tbody tr');
                        const dados = [];
                        
                        linhas.forEach(linha => {
                            const cols = linha.querySelectorAll('td');
                            if (cols.length >= 4) {
                                const data = cols[0].textContent.trim();
                                let tipo = cols[1].textContent.trim();
                                const autor = cols[2].textContent.trim();
                                const ementa = cols[3].textContent.trim();
                                
                                // Extrair número do tipo
                                let numero = '0';
                                const partes = tipo.split(/\\s+/);
                                if (partes.length > 1 && /^\\d+$/.test(partes[partes.length - 1])) {
                                    numero = partes[partes.length - 1];
                                    tipo = partes.slice(0, -1).join(' ');
                                }
                                
                                dados.push({
                                    data_leitura: data,
                                    tipo: tipo,
                                    numero: numero,
                                    ano: '2025',
                                    autor: autor,
                                    ementa: ementa,
                                    situacao: 'Em tramitação'
                                });
                            }
                        });
                        
                        return dados;
                    }
                """)
                
                print(f"   ✅ Extraídas {len(dados_pagina)} proposições")
                proposicoes.extend(dados_pagina)
                
                # Verificar se há próxima página
                tem_proxima = page.evaluate("""
                    () => {
                        const nextBtn = document.querySelector('a[title*="próxima"]');
                        return nextBtn && !nextBtn.classList.contains('disabled');
                    }
                """)
                
                if tem_proxima:
                    print("➡️  Indo para próxima página...")
                    page.click('a[title*="próxima"]')
                    time.sleep(3)
                    pagina += 1
                else:
                    print("✅ Última página alcançada")
                    break
            
            print(f"\n✅ Coleta concluída! Total: {len(proposicoes)} proposições")
            
        except Exception as e:
            print(f"\n❌ Erro: {e}")
            import traceback
            traceback.print_exc()
            
            # Salvar HTML para debug
            try:
                html = page.content()
                with open("/home/ubuntu/sgpl_debug.html", "w") as f:
                    f.write(html)
                print("📝 HTML salvo para debug: /home/ubuntu/sgpl_debug.html")
            except:
                pass
        
        finally:
            browser.close()
    
    return proposicoes

def main():
    print("=" * 70)
    print("COLETA SGPL v2 - ROBUSTA")
    print("=" * 70)
    
    proposicoes = coletar_proposicoes_sgpl()
    
    if proposicoes:
        output = "/home/ubuntu/sistema-monitoramento-fiems/data/proposicoes_sgpl_completas.json"
        with open(output, "w", encoding="utf-8") as f:
            json.dump(proposicoes, f, ensure_ascii=False, indent=2)
        
        print(f"\n💾 Salvo em: {output}")
        print(f"📊 Total: {len(proposicoes)} proposições")
        
        # Estatísticas
        tipos = {}
        for p in proposicoes:
            tipos[p["tipo"]] = tipos.get(p["tipo"], 0) + 1
        
        print("\n📈 Por tipo:")
        for tipo, qtd in sorted(tipos.items(), key=lambda x: -x[1]):
            print(f"   {tipo}: {qtd}")
        
        return 0
    else:
        print("\n❌ Falha na coleta")
        return 1

if __name__ == "__main__":
    exit(main())
