#!/usr/bin/env python3
"""
Script para corrigir URLs faltantes nas proposições existentes
"""
import logging
from supabase import create_client, Client
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Configuração Supabase
SUPABASE_URL = "https://ovmyzfdspddexpvpnpjk.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im92bXl6ZmRzcGRkZXhwdnBucGprIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIzNTE5NDcsImV4cCI6MjA3NzkyNzk0N30.4sNVHtKnwHMmRxheIQLuKt4qZfy_nG2wCn3ueQq5nCM"

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

TABELA_PROPOSICOES = "proposicoes_legislativas_2025_11_05_16_31"
SGPL_BASE_URL = "https://sgpl.consulta.al.ms.gov.br/sgpl-publico"

def corrigir_urls():
    """Corrige URLs faltantes nas proposições"""
    logger.info("Buscando proposições sem URL...")
    
    # Buscar proposições sem URL
    response = supabase.table(TABELA_PROPOSICOES).select("*").is_("url_origem", "null").execute()
    proposicoes_sem_url = response.data
    
    logger.info(f"Encontradas {len(proposicoes_sem_url)} proposições sem URL")
    
    corrigidas = 0
    
    for prop in proposicoes_sem_url:
        # Gerar URL baseada no tipo, número e ano
        # Formato exemplo: https://sgpl.consulta.al.ms.gov.br/sgpl-publico/proposicoes/PL-123-2025
        tipo_sigla = prop.get('tipo', '').replace(' ', '-')
        numero = prop.get('numero', '0')
        ano = prop.get('ano', '2025')
        
        # URL genérica do SGPL (ajustar conforme estrutura real)
        url_gerada = f"{SGPL_BASE_URL}/proposicoes/buscar?tipo={tipo_sigla}&numero={numero}&ano={ano}"
        
        # Atualizar no banco
        try:
            supabase.table(TABELA_PROPOSICOES).update({
                'url_origem': url_gerada,
                'updated_at': datetime.now().isoformat()
            }).eq('id', prop['id']).execute()
            
            logger.info(f"✓ URL corrigida para proposição {prop['id']}")
            corrigidas += 1
            
        except Exception as e:
            logger.error(f"✗ Erro ao atualizar proposição {prop['id']}: {e}")
    
    logger.info(f"=== CORREÇÃO CONCLUÍDA ===")
    logger.info(f"URLs corrigidas: {corrigidas}")

if __name__ == "__main__":
    corrigir_urls()
