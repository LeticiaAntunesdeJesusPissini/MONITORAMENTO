#!/usr/bin/env python3
"""
Script para coletar TODAS as proposições de 03-06/11/2025 do SGPL
com números corretos, ementas completas e informações de tramitação
"""

import requests
import json
import time
from datetime import datetime
from bs4 import BeautifulSoup

# URL base do SGPL
SGPL_BASE_URL = "https://sgpl.consulta.al.ms.gov.br/sgpl-publico"
SGPL_API_URL = f"{SGPL_BASE_URL}/api/proposicoes"

def buscar_proposicoes_por_periodo(data_inicio, data_fim):
    """
    Busca proposições no SGPL por período de data
    """
    print(f"🔍 Buscando proposições de {data_inicio} a {data_fim}...")
    
    # Parâmetros da busca
    params = {
        "dataLeituraInicio": data_inicio,
        "dataLeituraFim": data_fim,
        "page": 0,
        "size": 100  # Pegar todas de uma vez
    }
    
    try:
        response = requests.get(SGPL_API_URL, params=params, timeout=30)
        response.raise_for_status()
        dados = response.json()
        
        total = dados.get("totalElements", 0)
        proposicoes = dados.get("content", [])
        
        print(f"✅ Encontradas {total} proposições")
        return proposicoes
        
    except Exception as e:
        print(f"❌ Erro ao buscar proposições: {e}")
        return []

def extrair_detalhes_proposicao(prop_id):
    """
    Extrai detalhes completos de uma proposição específica
    """
    try:
        url = f"{SGPL_API_URL}/{prop_id}"
        response = requests.get(url, timeout=15)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        print(f"⚠️  Erro ao extrair detalhes da proposição {prop_id}: {e}")
        return None

def processar_proposicoes():
    """
    Processa todas as proposições de 03-06/11/2025
    """
    # Buscar proposições do período
    proposicoes = buscar_proposicoes_por_periodo("03/11/2025", "06/11/2025")
    
    if not proposicoes:
        print("❌ Nenhuma proposição encontrada")
        return []
    
    proposicoes_processadas = []
    
    for i, prop in enumerate(proposicoes, 1):
        print(f"\n📄 Processando {i}/{len(proposicoes)}: {prop.get('tipo', '')} {prop.get('numero', '')}...")
        
        # Extrair dados básicos
        proposicao_data = {
            "id": prop.get("id"),
            "tipo": prop.get("tipo", ""),
            "numero": prop.get("numero", "0"),
            "ano": prop.get("ano", "2025"),
            "ementa": prop.get("ementa", ""),
            "autor": prop.get("autor", {}).get("nome", ""),
            "data_leitura": prop.get("dataLeitura", ""),
            "situacao": prop.get("situacao", {}).get("descricao", "Em tramitação"),
        }
        
        # Tentar extrair detalhes adicionais
        detalhes = extrair_detalhes_proposicao(prop.get("id"))
        if detalhes:
            proposicao_data["tramitacao"] = detalhes.get("tramitacao", "")
            proposicao_data["texto_completo"] = detalhes.get("textoCompleto", "")
        
        proposicoes_processadas.append(proposicao_data)
        
        # Aguardar um pouco para não sobrecarregar o servidor
        time.sleep(0.5)
    
    return proposicoes_processadas

def salvar_dados(proposicoes):
    """
    Salva proposições em arquivo JSON
    """
    output_file = "/home/ubuntu/sistema-monitoramento-fiems/data/proposicoes_03_06_nov_2025.json"
    
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(proposicoes, f, ensure_ascii=False, indent=2)
    
    print(f"\n✅ Dados salvos em: {output_file}")
    print(f"📊 Total de proposições coletadas: {len(proposicoes)}")

def main():
    print("=" * 60)
    print("COLETA COMPLETA DE PROPOSIÇÕES - SGPL ALEMS")
    print("Período: 03/11/2025 a 06/11/2025")
    print("=" * 60)
    
    # Processar proposições
    proposicoes = processar_proposicoes()
    
    if proposicoes:
        # Salvar dados
        salvar_dados(proposicoes)
        
        # Estatísticas
        print("\n📈 ESTATÍSTICAS:")
        print(f"   Total: {len(proposicoes)} proposições")
        
        tipos = {}
        for prop in proposicoes:
            tipo = prop["tipo"]
            tipos[tipo] = tipos.get(tipo, 0) + 1
        
        print("\n   Por tipo:")
        for tipo, qtd in sorted(tipos.items()):
            print(f"   - {tipo}: {qtd}")
    else:
        print("\n❌ Nenhuma proposição foi coletada")

if __name__ == "__main__":
    main()
