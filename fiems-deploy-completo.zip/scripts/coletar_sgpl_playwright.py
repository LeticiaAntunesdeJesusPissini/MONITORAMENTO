#!/usr/bin/env python3
"""
Script robusto para coletar TODAS as proposições de 03-06/11/2025 do SGPL
usando Playwright para automação web
"""

import json
import time
from playwright.sync_api import sync_playwright
from datetime import datetime

def coletar_proposicoes_sgpl():
    """
    Coleta todas as proposições de 03-06/11/2025 do SGPL
    """
    proposicoes = []
    
    with sync_playwright() as p:
        # Iniciar browser
        print("🚀 Iniciando navegador...")
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        
        try:
            # Acessar SGPL
            print("📡 Acessando SGPL...")
            page.goto("https://sgpl.consulta.al.ms.gov.br/sgpl-publico/#/busca-proposicoes", 
                     wait_until="networkidle", timeout=60000)
            
            time.sleep(3)
            
            # Clicar em Pesquisa Avançada
            print("🔍 Abrindo Pesquisa Avançada...")
            page.click("text=Pesquisa Avançada")
            time.sleep(2)
            
            # Preencher data inicial
            print("📅 Preenchendo datas...")
            data_inputs = page.query_selector_all('input[type="text"]')
            
            # Encontrar campos de data (geralmente os últimos inputs)
            for inp in data_inputs:
                placeholder = inp.get_attribute("placeholder")
                if placeholder == "" or placeholder is None:
                    # Pode ser campo de data
                    try:
                        inp.fill("03/11/2025")
                        break
                    except:
                        continue
            
            time.sleep(1)
            
            # Preencher data final
            for inp in reversed(data_inputs):
                placeholder = inp.get_attribute("placeholder")
                if placeholder == "" or placeholder is None:
                    try:
                        inp.fill("06/11/2025")
                        break
                    except:
                        continue
            
            time.sleep(1)
            
            # Clicar em Pesquisar
            print("🔎 Executando busca...")
            page.click("button:has-text('Pesquisar')")
            time.sleep(5)
            
            # Aguardar resultados carregarem
            page.wait_for_selector("table tbody tr", timeout=30000)
            
            # Verificar quantas páginas existem
            print("📊 Contando resultados...")
            pagination_text = page.text_content(".pagination") or ""
            
            # Extrair dados de todas as páginas
            pagina_atual = 1
            tem_mais_paginas = True
            
            while tem_mais_paginas:
                print(f"\n📄 Processando página {pagina_atual}...")
                
                # Extrair dados da tabela
                linhas = page.query_selector_all("table tbody tr")
                print(f"   Encontradas {len(linhas)} proposições nesta página")
                
                for i, linha in enumerate(linhas, 1):
                    try:
                        colunas = linha.query_selector_all("td")
                        
                        if len(colunas) >= 4:
                            data_leitura = colunas[0].text_content().strip()
                            tipo = colunas[1].text_content().strip()
                            autor = colunas[2].text_content().strip()
                            ementa = colunas[3].text_content().strip()
                            
                            # Extrair número do tipo (ex: "Indicação 123" -> numero=123)
                            numero = "0"
                            if " " in tipo:
                                partes = tipo.split()
                                if len(partes) > 1 and partes[-1].isdigit():
                                    numero = partes[-1]
                                    tipo = " ".join(partes[:-1])
                            
                            proposicao = {
                                "data_leitura": data_leitura,
                                "tipo": tipo,
                                "numero": numero,
                                "ano": "2025",
                                "autor": autor,
                                "ementa": ementa,
                                "situacao": "Em tramitação"
                            }
                            
                            proposicoes.append(proposicao)
                            print(f"   ✅ {i}. {tipo} {numero} - {autor[:30]}...")
                    
                    except Exception as e:
                        print(f"   ⚠️  Erro ao processar linha {i}: {e}")
                        continue
                
                # Verificar se há próxima página
                try:
                    next_button = page.query_selector("a[title='Ir para a próxima página']")
                    if next_button and not next_button.is_disabled():
                        print("\n➡️  Indo para próxima página...")
                        next_button.click()
                        time.sleep(3)
                        pagina_atual += 1
                    else:
                        tem_mais_paginas = False
                except:
                    tem_mais_paginas = False
            
            print(f"\n✅ Coleta concluída! Total: {len(proposicoes)} proposições")
            
        except Exception as e:
            print(f"\n❌ Erro durante coleta: {e}")
            import traceback
            traceback.print_exc()
        
        finally:
            browser.close()
    
    return proposicoes

def salvar_proposicoes(proposicoes):
    """
    Salva proposições em arquivo JSON
    """
    output_file = "/home/ubuntu/sistema-monitoramento-fiems/data/proposicoes_sgpl_completas.json"
    
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(proposicoes, f, ensure_ascii=False, indent=2)
    
    print(f"\n💾 Dados salvos em: {output_file}")
    return output_file

def main():
    print("=" * 70)
    print("COLETA COMPLETA DE PROPOSIÇÕES - SGPL ALEMS (Playwright)")
    print("Período: 03/11/2025 a 06/11/2025")
    print("=" * 70)
    
    # Coletar proposições
    proposicoes = coletar_proposicoes_sgpl()
    
    if proposicoes:
        # Salvar dados
        arquivo = salvar_proposicoes(proposicoes)
        
        # Estatísticas
        print("\n📈 ESTATÍSTICAS:")
        print(f"   Total coletado: {len(proposicoes)} proposições")
        
        tipos = {}
        for prop in proposicoes:
            tipo = prop["tipo"]
            tipos[tipo] = tipos.get(tipo, 0) + 1
        
        print("\n   Por tipo:")
        for tipo, qtd in sorted(tipos.items(), key=lambda x: -x[1]):
            print(f"   - {tipo}: {qtd}")
        
        print(f"\n✅ Coleta concluída com sucesso!")
        print(f"📁 Arquivo: {arquivo}")
    else:
        print("\n❌ Nenhuma proposição foi coletada")
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main())
