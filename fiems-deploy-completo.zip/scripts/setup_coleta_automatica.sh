#!/bin/bash
"""
Script para configurar coleta automática diária
Executa coletores em horários programados
"""

echo "=== Configurando Coleta Automática FIEMS ==="

# Criar diretório de logs
sudo mkdir -p /var/log/fiems
sudo chown ubuntu:ubuntu /var/log/fiems

# Criar arquivo de cron
cat > /tmp/fiems-cron << 'CRONEOF'
# Coleta Automática - Sistema de Monitoramento Legislativo FIEMS
# Executado diariamente

# Coleta de proposições legislativas - 8h00
0 8 * * * cd /home/ubuntu/sistema-monitoramento-fiems && /usr/bin/python3 scripts/coletor_proposicoes_robusto.py >> /var/log/fiems/coleta-proposicoes.log 2>&1

# Coleta de atos executivos - 9h00
0 9 * * * cd /home/ubuntu/sistema-monitoramento-fiems && /usr/bin/python3 scripts/adicionar_decretos_novembro.py >> /var/log/fiems/coleta-atos.log 2>&1

# Geração de análises de IA - 10h00
0 10 * * * cd /home/ubuntu/sistema-monitoramento-fiems && /usr/bin/python3 scripts/gerar_analises_ia.py >> /var/log/fiems/analises-ia.log 2>&1

# Auditoria de dados - Domingo às 23h00
0 23 * * 0 cd /home/ubuntu/sistema-monitoramento-fiems && /usr/bin/python3 scripts/auditar_dados.py >> /var/log/fiems/auditoria.log 2>&1

CRONEOF

# Instalar cron job
sudo cp /tmp/fiems-cron /etc/cron.d/fiems-coleta
sudo chmod 0644 /etc/cron.d/fiems-coleta
sudo chown root:root /etc/cron.d/fiems-coleta

echo "✓ Cron jobs instalados"

# Criar script de monitoramento
cat > /home/ubuntu/sistema-monitoramento-fiems/scripts/monitorar_coletas.sh << 'MONITOREOF'
#!/bin/bash
# Script para monitorar status das coletas

echo "=== Status das Coletas FIEMS ==="
echo ""

# Verificar logs recentes
echo "Últimas coletas de proposições:"
tail -5 /var/log/fiems/coleta-proposicoes.log 2>/dev/null || echo "Nenhuma coleta registrada"

echo ""
echo "Últimas coletas de atos:"
tail -5 /var/log/fiems/coleta-atos.log 2>/dev/null || echo "Nenhuma coleta registrada"

echo ""
echo "Últimas análises:"
tail -5 /var/log/fiems/analises-ia.log 2>/dev/null || echo "Nenhuma análise registrada"

# Verificar se cron está rodando
echo ""
if systemctl is-active --quiet cron; then
    echo "✓ Serviço cron está ativo"
else
    echo "✗ Serviço cron NÃO está ativo"
fi

# Listar próximas execuções
echo ""
echo "Próximas execuções programadas:"
grep -v "^#" /etc/cron.d/fiems-coleta 2>/dev/null || echo "Nenhuma execução programada"

MONITOREOF

chmod +x /home/ubuntu/sistema-monitoramento-fiems/scripts/monitorar_coletas.sh

echo "✓ Script de monitoramento criado"
echo ""
echo "=== Configuração Concluída ==="
echo ""
echo "Coletas programadas:"
echo "  - 08:00 - Proposições legislativas"
echo "  - 09:00 - Atos executivos"
echo "  - 10:00 - Análises de IA"
echo "  - 23:00 (Domingo) - Auditoria de dados"
echo ""
echo "Para monitorar as coletas, execute:"
echo "  ./scripts/monitorar_coletas.sh"
echo ""
echo "Logs disponíveis em:"
echo "  /var/log/fiems/"
