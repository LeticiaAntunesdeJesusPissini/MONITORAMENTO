#!/usr/bin/env python3
"""
Script para adicionar decretos de novembro de 2025 ao banco de dados
"""
import os
from supabase import create_client, Client
from datetime import datetime
import uuid

# Configuração do Supabase
SUPABASE_URL = os.getenv("SUPABASE_URL", "https://bnvjjvxfvqwsqxlxaqpk.supabase.co")
SUPABASE_KEY = os.getenv("SUPABASE_ANON_KEY")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# Decretos a serem adicionados
decretos = [
    {
        "tipo": "Decreto",
        "numero": "16.688",
        "ano": "2025",
        "data_publicacao": "2025-11-05",
        "ementa": "Altera a redação e acrescenta dispositivos ao Subanexo XVII – Do Manifesto Eletrônico de Documentos Fiscais (MDF-e), e acrescenta dispositivos ao Subanexo XII – Da Nota Fiscal Eletrônica (NF-e) e o Documento Auxiliar da Nota Fiscal Eletrônica (DANFE), ambos do Anexo XV das Obrigações Acessórias, ao Regulamento do ICMS.",
        "orgao_origem": "Governo do Estado de Mato Grosso do Sul",
        "impacto_fiscal": True,
        "fonte_url": "https://www.diariooficial.ms.gov.br/",
        "classificacao_tematica": "Tributário",
        "grau_impacto": "Alto",
        "setores_afetados": ["Industrial", "Logística", "Transporte", "Comércio"],
        "analise": {
            "impacto_tributario": {
                "nivel": "Alto",
                "descricao": "Alterações nas regras de emissão de MDF-e e NF-e afetam diretamente as obrigações acessórias do ICMS para empresas que realizam transporte de mercadorias"
            },
            "impacto_empresarial": {
                "nivel": "Alto",
                "descricao": "Empresas precisarão adequar seus sistemas de emissão de documentos fiscais eletrônicos às novas regras estabelecidas pelo Ajuste SINIEF"
            },
            "impacto_economico": {
                "nivel": "Médio",
                "descricao": "Custos de adequação de sistemas e processos internos para conformidade com as novas regras"
            },
            "recomendacao_acao": "AÇÃO IMEDIATA: Decreto altera obrigações acessórias do ICMS. Empresas devem revisar processos de emissão de documentos fiscais eletrônicos e adequar sistemas até a data de vigência.",
            "justificativa": "Decreto implementa alterações dos Ajustes SINIEF 13/24, 15/25, 21/10 e 26/24 do CONFAZ, modificando regras de emissão de MDF-e e NF-e que impactam todas as empresas que transportam mercadorias.",
            "grau_risco": "Alto",
            "grau_oportunidade": "Baixo"
        }
    },
    {
        "tipo": "Decreto",
        "numero": "16.689",
        "ano": "2025",
        "data_publicacao": "2025-11-05",
        "ementa": "Altera a redação e acrescenta dispositivos ao Anexo IX - Do Parcelamento de Débitos Fiscais, ao Regulamento do ICMS, aprovado pelo Decreto nº 9.203, de 18 de setembro de 1998, com a redação dada pelo Decreto nº 15.571, de 28 de dezembro de 2020.",
        "orgao_origem": "Governo do Estado de Mato Grosso do Sul",
        "impacto_fiscal": True,
        "fonte_url": "https://www.diariooficial.ms.gov.br/",
        "classificacao_tematica": "Tributário",
        "grau_impacto": "Alto",
        "setores_afetados": ["Todos os setores empresariais"],
        "analise": {
            "impacto_tributario": {
                "nivel": "Alto",
                "descricao": "Alterações nas regras de parcelamento de débitos fiscais do ICMS e outros créditos estaduais, facilitando negociação de dívidas tributárias"
            },
            "impacto_empresarial": {
                "nivel": "Alto",
                "descricao": "Novas regras de parcelamento podem beneficiar empresas com débitos fiscais, permitindo regularização com condições mais favoráveis"
            },
            "impacto_economico": {
                "nivel": "Alto",
                "descricao": "Facilita regularização fiscal de empresas endividadas, melhorando fluxo de caixa e permitindo retomada de atividades"
            },
            "recomendacao_acao": "OPORTUNIDADE: Decreto altera regras de parcelamento de débitos fiscais. Empresas com dívidas tributárias devem avaliar possibilidade de renegociação sob as novas condições.",
            "justificativa": "Decreto amplia possibilidades de parcelamento de débitos fiscais do ICMS e outros créditos estaduais, estabelecendo valor mínimo de 10 UFERMS por parcela e estendendo aplicação para débitos não fazendários.",
            "grau_risco": "Baixo",
            "grau_oportunidade": "Alto"
        }
    }
]

def adicionar_decretos():
    """Adiciona decretos ao banco de dados"""
    tabela_atos = "atos_executivo_2025_11_05_16_31"
    tabela_analises = "analises_impacto_2025_11_05_16_31"
    
    for decreto in decretos:
        # Criar ID único
        ato_id = str(uuid.uuid4())
        
        # Preparar dados do ato
        ato_data = {
            "id": ato_id,
            "tipo": decreto["tipo"],
            "numero": decreto["numero"],
            "ano": decreto["ano"],
            "data_publicacao": decreto["data_publicacao"],
            "ementa": decreto["ementa"],
            "orgao_origem": decreto["orgao_origem"],
            "impacto_fiscal": decreto["impacto_fiscal"],
            "fonte_url": decreto["fonte_url"],
            "classificacao_tematica": decreto["classificacao_tematica"],
            "grau_impacto": decreto["grau_impacto"],
            "setores_afetados": decreto["setores_afetados"]
        }
        
        # Inserir ato
        try:
            result_ato = supabase.table(tabela_atos).insert(ato_data).execute()
            print(f"✅ Decreto {decreto['numero']}/{decreto['ano']} adicionado com sucesso!")
            
            # Preparar dados da análise
            analise_data = {
                "id": str(uuid.uuid4()),
                "documento_id": ato_id,
                "tipo_documento": "ato_executivo",
                "impacto_tributario": decreto["analise"]["impacto_tributario"],
                "impacto_empresarial": decreto["analise"]["impacto_empresarial"],
                "impacto_economico": decreto["analise"]["impacto_economico"],
                "recomendacao_acao": decreto["analise"]["recomendacao_acao"],
                "justificativa": decreto["analise"]["justificativa"],
                "grau_risco": decreto["analise"]["grau_risco"],
                "grau_oportunidade": decreto["analise"]["grau_oportunidade"],
                "data_analise": datetime.now().isoformat()
            }
            
            # Inserir análise
            result_analise = supabase.table(tabela_analises).insert(analise_data).execute()
            print(f"✅ Análise do Decreto {decreto['numero']}/{decreto['ano']} adicionada com sucesso!")
            
        except Exception as e:
            print(f"❌ Erro ao adicionar Decreto {decreto['numero']}/{decreto['ano']}: {e}")

if __name__ == "__main__":
    print("🚀 Iniciando adição de decretos de novembro de 2025...")
    adicionar_decretos()
    print("\n✅ Processo concluído!")
