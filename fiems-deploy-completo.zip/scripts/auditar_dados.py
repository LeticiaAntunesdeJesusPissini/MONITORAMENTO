#!/usr/bin/env python3
"""
Script para auditar dados no Supabase e identificar problemas
"""
import os
import sys
from supabase import create_client, Client
from datetime import datetime
import json

# Configuração Supabase
SUPABASE_URL = "https://ovmyzfdspddexpvpnpjk.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im92bXl6ZmRzcGRkZXhwdnBucGprIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIzNTE5NDcsImV4cCI6MjA3NzkyNzk0N30.4sNVHtKnwHMmRxheIQLuKt4qZfy_nG2wCn3ueQq5nCM"

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# Tabelas
TABELA_PROPOSICOES = "proposicoes_legislativas_2025_11_05_16_31"
TABELA_ATOS = "atos_executivo_2025_11_05_16_31"
TABELA_ANALISES = "analises_impacto_2025_11_05_16_31"
TABELA_ALERTAS = "alertas_2025_11_05_16_31"

def auditar_proposicoes():
    """Audita tabela de proposições"""
    print("\n" + "="*80)
    print("AUDITORIA DE PROPOSIÇÕES LEGISLATIVAS")
    print("="*80)
    
    response = supabase.table(TABELA_PROPOSICOES).select("*").execute()
    proposicoes = response.data
    
    total = len(proposicoes)
    print(f"\nTotal de proposições: {total}")
    
    # Problemas identificados
    sem_numero = []
    numero_zero = []
    sem_ementa = []
    sem_autor = []
    sem_url = []
    sem_classificacao = []
    sem_grau_impacto = []
    
    for prop in proposicoes:
        # Número inválido
        if not prop.get('numero') or prop.get('numero') == '':
            sem_numero.append(prop['id'])
        elif prop.get('numero') == '0':
            numero_zero.append(prop['id'])
        
        # Ementa vazia ou muito curta
        if not prop.get('ementa') or len(prop.get('ementa', '')) < 10:
            sem_ementa.append(prop['id'])
        
        # Autor vazio
        if not prop.get('autor'):
            sem_autor.append(prop['id'])
        
        # URL vazia
        if not prop.get('url_origem'):
            sem_url.append(prop['id'])
        
        # Classificação vazia
        if not prop.get('classificacao_tematica'):
            sem_classificacao.append(prop['id'])
        
        # Grau de impacto vazio
        if not prop.get('grau_impacto'):
            sem_grau_impacto.append(prop['id'])
    
    # Relatório
    print(f"\n📊 PROBLEMAS IDENTIFICADOS:")
    print(f"  - Sem número: {len(sem_numero)}")
    print(f"  - Número = '0': {len(numero_zero)}")
    print(f"  - Sem ementa ou ementa curta: {len(sem_ementa)}")
    print(f"  - Sem autor: {len(sem_autor)}")
    print(f"  - Sem URL de origem: {len(sem_url)}")
    print(f"  - Sem classificação temática: {len(sem_classificacao)}")
    print(f"  - Sem grau de impacto: {len(sem_grau_impacto)}")
    
    # Calcular % de qualidade
    problemas_total = (len(sem_numero) + len(numero_zero) + len(sem_ementa) + 
                      len(sem_autor) + len(sem_url) + len(sem_classificacao) + 
                      len(sem_grau_impacto))
    
    qualidade = 100 - (problemas_total / (total * 7) * 100) if total > 0 else 0
    print(f"\n✅ Qualidade geral dos dados: {qualidade:.1f}%")
    
    # Salvar relatório detalhado
    relatorio = {
        "data_auditoria": datetime.now().isoformat(),
        "total_proposicoes": total,
        "problemas": {
            "sem_numero": sem_numero,
            "numero_zero": numero_zero,
            "sem_ementa": sem_ementa,
            "sem_autor": sem_autor,
            "sem_url": sem_url,
            "sem_classificacao": sem_classificacao,
            "sem_grau_impacto": sem_grau_impacto
        },
        "qualidade_percentual": qualidade
    }
    
    return relatorio

def auditar_atos():
    """Audita tabela de atos executivos"""
    print("\n" + "="*80)
    print("AUDITORIA DE ATOS EXECUTIVOS")
    print("="*80)
    
    response = supabase.table(TABELA_ATOS).select("*").execute()
    atos = response.data
    
    total = len(atos)
    print(f"\nTotal de atos: {total}")
    
    # Problemas identificados
    sem_numero = []
    sem_ementa = []
    sem_orgao = []
    sem_url = []
    sem_data_publicacao = []
    
    for ato in atos:
        if not ato.get('numero'):
            sem_numero.append(ato['id'])
        if not ato.get('ementa') or len(ato.get('ementa', '')) < 10:
            sem_ementa.append(ato['id'])
        if not ato.get('orgao_origem'):
            sem_orgao.append(ato['id'])
        if not ato.get('url_doe'):
            sem_url.append(ato['id'])
        if not ato.get('data_publicacao'):
            sem_data_publicacao.append(ato['id'])
    
    # Relatório
    print(f"\n📊 PROBLEMAS IDENTIFICADOS:")
    print(f"  - Sem número: {len(sem_numero)}")
    print(f"  - Sem ementa ou ementa curta: {len(sem_ementa)}")
    print(f"  - Sem órgão de origem: {len(sem_orgao)}")
    print(f"  - Sem URL do DOE: {len(sem_url)}")
    print(f"  - Sem data de publicação: {len(sem_data_publicacao)}")
    
    problemas_total = (len(sem_numero) + len(sem_ementa) + len(sem_orgao) + 
                      len(sem_url) + len(sem_data_publicacao))
    
    qualidade = 100 - (problemas_total / (total * 5) * 100) if total > 0 else 0
    print(f"\n✅ Qualidade geral dos dados: {qualidade:.1f}%")
    
    relatorio = {
        "data_auditoria": datetime.now().isoformat(),
        "total_atos": total,
        "problemas": {
            "sem_numero": sem_numero,
            "sem_ementa": sem_ementa,
            "sem_orgao": sem_orgao,
            "sem_url": sem_url,
            "sem_data_publicacao": sem_data_publicacao
        },
        "qualidade_percentual": qualidade
    }
    
    return relatorio

def auditar_analises():
    """Audita tabela de análises"""
    print("\n" + "="*80)
    print("AUDITORIA DE ANÁLISES DE IMPACTO")
    print("="*80)
    
    response = supabase.table(TABELA_ANALISES).select("*").execute()
    analises = response.data
    
    total = len(analises)
    print(f"\nTotal de análises: {total}")
    
    # Verificar análises órfãs
    response_prop = supabase.table(TABELA_PROPOSICOES).select("id").execute()
    ids_proposicoes = {p['id'] for p in response_prop.data}
    
    response_atos = supabase.table(TABELA_ATOS).select("id").execute()
    ids_atos = {a['id'] for a in response_atos.data}
    
    orfas = []
    sem_recomendacao = []
    
    for analise in analises:
        prop_id = analise.get('proposicao_id')
        ato_id = analise.get('ato_executivo_id')
        
        if prop_id and prop_id not in ids_proposicoes:
            orfas.append(analise['id'])
        if ato_id and ato_id not in ids_atos:
            orfas.append(analise['id'])
        
        if not analise.get('recomendacao_acao'):
            sem_recomendacao.append(analise['id'])
    
    print(f"\n📊 PROBLEMAS IDENTIFICADOS:")
    print(f"  - Análises órfãs (sem documento correspondente): {len(orfas)}")
    print(f"  - Sem recomendação de ação: {len(sem_recomendacao)}")
    
    relatorio = {
        "data_auditoria": datetime.now().isoformat(),
        "total_analises": total,
        "problemas": {
            "orfas": orfas,
            "sem_recomendacao": sem_recomendacao
        }
    }
    
    return relatorio

def main():
    print("\n🔍 AUDITORIA COMPLETA DO BANCO DE DADOS FIEMS")
    print(f"Data: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    
    # Auditar cada tabela
    relatorio_proposicoes = auditar_proposicoes()
    relatorio_atos = auditar_atos()
    relatorio_analises = auditar_analises()
    
    # Consolidar relatório
    relatorio_completo = {
        "proposicoes": relatorio_proposicoes,
        "atos": relatorio_atos,
        "analises": relatorio_analises
    }
    
    # Salvar em arquivo
    arquivo_relatorio = f"/home/ubuntu/relatorio_auditoria_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(arquivo_relatorio, 'w', encoding='utf-8') as f:
        json.dump(relatorio_completo, f, indent=2, ensure_ascii=False)
    
    print(f"\n💾 Relatório salvo em: {arquivo_relatorio}")
    
    # Resumo final
    print("\n" + "="*80)
    print("RESUMO GERAL")
    print("="*80)
    print(f"Proposições: {relatorio_proposicoes['total_proposicoes']} registros - Qualidade: {relatorio_proposicoes['qualidade_percentual']:.1f}%")
    print(f"Atos: {relatorio_atos['total_atos']} registros - Qualidade: {relatorio_atos['qualidade_percentual']:.1f}%")
    print(f"Análises: {relatorio_analises['total_analises']} registros")
    
    # Determinar ação necessária
    if relatorio_proposicoes['qualidade_percentual'] < 90 or relatorio_atos['qualidade_percentual'] < 90:
        print("\n⚠️  AÇÃO NECESSÁRIA: Qualidade dos dados abaixo de 90%")
        print("   Recomenda-se limpeza e recoleta de dados")
    else:
        print("\n✅ Qualidade dos dados aceitável")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n❌ Erro durante auditoria: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
