import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Filter, 
  X, 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown,
  Calendar,
  User,
  FileText,
  TrendingUp
} from "lucide-react";

export interface FilterOptions {
  tipo?: string;
  impacto?: string;
  status?: string;
  dataInicio?: string;
  dataFim?: string;
  autor?: string;
  classificacao?: string;
  busca?: string;
}

export interface SortOptions {
  campo: 'data' | 'sigla' | 'numero' | 'impacto' | 'tipo';
  ordem: 'asc' | 'desc';
}

interface FilterBarProps {
  onFilterChange: (filters: FilterOptions) => void;
  onSortChange: (sort: SortOptions) => void;
  resultCount?: number;
  tiposDisponiveis?: string[];
  autoresDisponiveis?: string[];
  classificacoesDisponiveis?: string[];
}

export default function FilterBar({
  onFilterChange,
  onSortChange,
  resultCount,
  tiposDisponiveis = [],
  autoresDisponiveis = [],
  classificacoesDisponiveis = []
}: FilterBarProps) {
  const [mostrarFiltros, setMostrarFiltros] = useState(false);
  const [filtros, setFiltros] = useState<FilterOptions>({});
  const [ordenacao, setOrdenacao] = useState<SortOptions>({
    campo: 'data',
    ordem: 'desc'
  });

  const handleFilterChange = (key: keyof FilterOptions, value: string) => {
    const novosFiltros = { ...filtros, [key]: value || undefined };
    setFiltros(novosFiltros);
    onFilterChange(novosFiltros);
  };

  const limparFiltros = () => {
    setFiltros({});
    onFilterChange({});
  };

  const handleSortChange = (campo: SortOptions['campo']) => {
    const novaOrdenacao: SortOptions = {
      campo,
      ordem: ordenacao.campo === campo && ordenacao.ordem === 'asc' ? 'desc' : 'asc'
    };
    setOrdenacao(novaOrdenacao);
    onSortChange(novaOrdenacao);
  };

  const contarFiltrosAtivos = () => {
    return Object.values(filtros).filter(v => v !== undefined && v !== '').length;
  };

  const filtrosAtivos = contarFiltrosAtivos();

  const getSortIcon = (campo: SortOptions['campo']) => {
    if (ordenacao.campo !== campo) {
      return <ArrowUpDown className="w-4 h-4" />;
    }
    return ordenacao.ordem === 'asc' 
      ? <ArrowUp className="w-4 h-4" /> 
      : <ArrowDown className="w-4 h-4" />;
  };

  return (
    <div className="space-y-4">
      {/* Barra de controle */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <Button
            variant={mostrarFiltros ? "default" : "outline"}
            onClick={() => setMostrarFiltros(!mostrarFiltros)}
            className="gap-2"
          >
            <Filter className="w-4 h-4" />
            Filtros
            {filtrosAtivos > 0 && (
              <Badge variant="secondary" className="ml-1 px-1.5 py-0 text-xs">
                {filtrosAtivos}
              </Badge>
            )}
          </Button>

          {filtrosAtivos > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={limparFiltros}
              className="gap-2 text-muted-foreground hover:text-foreground"
            >
              <X className="w-4 h-4" />
              Limpar
            </Button>
          )}

          {resultCount !== undefined && (
            <span className="text-sm text-muted-foreground">
              {resultCount} {resultCount === 1 ? 'resultado' : 'resultados'}
            </span>
          )}
        </div>

        {/* Botões de ordenação */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-sm text-muted-foreground">Ordenar por:</span>
          
          <Button
            variant={ordenacao.campo === 'data' ? "default" : "outline"}
            size="sm"
            onClick={() => handleSortChange('data')}
            className="gap-2"
          >
            <Calendar className="w-4 h-4" />
            Data
            {getSortIcon('data')}
          </Button>

          <Button
            variant={ordenacao.campo === 'sigla' ? "default" : "outline"}
            size="sm"
            onClick={() => handleSortChange('sigla')}
            className="gap-2"
          >
            <FileText className="w-4 h-4" />
            Sigla
            {getSortIcon('sigla')}
          </Button>

          <Button
            variant={ordenacao.campo === 'impacto' ? "default" : "outline"}
            size="sm"
            onClick={() => handleSortChange('impacto')}
            className="gap-2"
          >
            <TrendingUp className="w-4 h-4" />
            Impacto
            {getSortIcon('impacto')}
          </Button>
        </div>
      </div>

      {/* Painel de filtros */}
      {mostrarFiltros && (
        <Card className="animate-in">
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Busca geral */}
              <div className="space-y-2 lg:col-span-3">
                <Label htmlFor="busca">Busca Geral</Label>
                <Input
                  id="busca"
                  placeholder="Buscar por ementa, autor, número..."
                  value={filtros.busca || ''}
                  onChange={(e) => handleFilterChange('busca', e.target.value)}
                />
              </div>

              {/* Tipo */}
              <div className="space-y-2">
                <Label htmlFor="tipo">Tipo de Proposição</Label>
                <Select
                  value={filtros.tipo || undefined}
                  onValueChange={(value) => handleFilterChange('tipo', value)}
                >
                  <SelectTrigger id="tipo">
                    <SelectValue placeholder="Todos os tipos" />
                  </SelectTrigger>
                  <SelectContent>
                    {tiposDisponiveis.length > 0 ? (
                      tiposDisponiveis.map((tipo) => (
                        <SelectItem key={tipo} value={tipo}>
                          {tipo}
                        </SelectItem>
                      ))
                    ) : (
                      <>
                        <SelectItem value="Projeto de Lei">Projeto de Lei</SelectItem>
                        <SelectItem value="Projeto de Lei Complementar">Projeto de Lei Complementar</SelectItem>
                        <SelectItem value="Proposta de Emenda Constitucional">PEC</SelectItem>
                        <SelectItem value="Projeto de Resolução">Projeto de Resolução</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>

              {/* Grau de Impacto */}
              <div className="space-y-2">
                <Label htmlFor="impacto">Grau de Impacto</Label>
                <Select
                  value={filtros.impacto || undefined}
                  onValueChange={(value) => handleFilterChange('impacto', value)}
                >
                  <SelectTrigger id="impacto">
                    <SelectValue placeholder="Todos os impactos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Alto">Alto</SelectItem>
                    <SelectItem value="Médio">Médio</SelectItem>
                    <SelectItem value="Baixo">Baixo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Status */}
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select
                  value={filtros.status || undefined}
                  onValueChange={(value) => handleFilterChange('status', value)}
                >
                  <SelectTrigger id="status">
                    <SelectValue placeholder="Todos os status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Em tramitação">Em tramitação</SelectItem>
                    <SelectItem value="Aprovado">Aprovado</SelectItem>
                    <SelectItem value="Rejeitado">Rejeitado</SelectItem>
                    <SelectItem value="Arquivado">Arquivado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Autor */}
              {autoresDisponiveis.length > 0 && (
                <div className="space-y-2">
                  <Label htmlFor="autor">Autor</Label>
                  <Select
                    value={filtros.autor || undefined}
                    onValueChange={(value) => handleFilterChange('autor', value)}
                  >
                    <SelectTrigger id="autor">
                      <SelectValue placeholder="Todos os autores" />
                    </SelectTrigger>
                    <SelectContent>
                      {autoresDisponiveis.map((autor) => (
                        <SelectItem key={autor} value={autor}>
                          {autor}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* Classificação Temática */}
              {classificacoesDisponiveis.length > 0 && (
                <div className="space-y-2">
                  <Label htmlFor="classificacao">Classificação Temática</Label>
                  <Select
                    value={filtros.classificacao || undefined}
                    onValueChange={(value) => handleFilterChange('classificacao', value)}
                  >
                    <SelectTrigger id="classificacao">
                      <SelectValue placeholder="Todas as classificações" />
                    </SelectTrigger>
                    <SelectContent>
                      {classificacoesDisponiveis.map((classificacao) => (
                        <SelectItem key={classificacao} value={classificacao}>
                          {classificacao}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* Data Início */}
              <div className="space-y-2">
                <Label htmlFor="dataInicio">Data Início</Label>
                <Input
                  id="dataInicio"
                  type="date"
                  value={filtros.dataInicio || ''}
                  onChange={(e) => handleFilterChange('dataInicio', e.target.value)}
                />
              </div>

              {/* Data Fim */}
              <div className="space-y-2">
                <Label htmlFor="dataFim">Data Fim</Label>
                <Input
                  id="dataFim"
                  type="date"
                  value={filtros.dataFim || ''}
                  onChange={(e) => handleFilterChange('dataFim', e.target.value)}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
