import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, X } from 'lucide-react';

interface SearchFiltersProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  status?: string;
  onStatusChange?: (value: string) => void;
  impacto?: string;
  onImpactoChange?: (value: string) => void;
  setor?: string;
  onSetorChange?: (value: string) => void;
  dataInicio?: string;
  onDataInicioChange?: (value: string) => void;
  dataFim?: string;
  onDataFimChange?: (value: string) => void;
  onClear: () => void;
  showImpacto?: boolean;
  showStatus?: boolean;
  showSetor?: boolean;
  showDates?: boolean;
}

const SETORES = [
  "Todos",
  "Frigoríficos e Abatedouros",
  "Laticínios",
  "Agroindústria",
  "Indústria Alimentícia",
  "Construção Civil",
  "Metalurgia",
  "Química e Petroquímica",
  "Papel e Celulose",
  "Têxtil e Confecções",
  "Mineração",
  "Energia",
  "Outros"
];

const STATUS_PROPOSICAO = [
  "Todos",
  "Em tramitação",
  "Aprovado",
  "Rejeitado",
  "Arquivado"
];

const STATUS_ANALISE = [
  "Todos",
  "pendente",
  "analisado"
];

const GRAUS_IMPACTO = [
  "Todos",
  "ALTO",
  "MÉDIO",
  "BAIXO"
];

export default function SearchFilters({
  searchTerm,
  onSearchChange,
  status,
  onStatusChange,
  impacto,
  onImpactoChange,
  setor,
  onSetorChange,
  dataInicio,
  onDataInicioChange,
  dataFim,
  onDataFimChange,
  onClear,
  showImpacto = false,
  showStatus = false,
  showSetor = false,
  showDates = false
}: SearchFiltersProps) {
  return (
    <div className="bg-slate-800 border border-slate-700 rounded-lg p-6 mb-6">
      <div className="flex items-center gap-2 mb-4">
        <Search className="w-5 h-5 text-slate-400" />
        <h3 className="text-lg font-semibold text-white">Busca Avançada</h3>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Busca por palavra-chave */}
        <div className="lg:col-span-3">
          <Label htmlFor="search" className="text-slate-300">
            Palavra-chave
          </Label>
          <Input
            id="search"
            type="text"
            placeholder="Digite para buscar..."
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className="mt-1 bg-slate-900 border-slate-700 text-white"
          />
        </div>

        {/* Filtro por Status */}
        {showStatus && onStatusChange && (
          <div>
            <Label htmlFor="status" className="text-slate-300">
              Status
            </Label>
            <Select value={status} onValueChange={onStatusChange}>
              <SelectTrigger className="mt-1 bg-slate-900 border-slate-700 text-white">
                <SelectValue placeholder="Selecione o status" />
              </SelectTrigger>
              <SelectContent>
                {STATUS_ANALISE.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Filtro por Grau de Impacto */}
        {showImpacto && onImpactoChange && (
          <div>
            <Label htmlFor="impacto" className="text-slate-300">
              Grau de Impacto
            </Label>
            <Select value={impacto} onValueChange={onImpactoChange}>
              <SelectTrigger className="mt-1 bg-slate-900 border-slate-700 text-white">
                <SelectValue placeholder="Selecione o impacto" />
              </SelectTrigger>
              <SelectContent>
                {GRAUS_IMPACTO.map((g) => (
                  <SelectItem key={g} value={g}>
                    {g}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Filtro por Setor */}
        {showSetor && onSetorChange && (
          <div>
            <Label htmlFor="setor" className="text-slate-300">
              Setor Industrial
            </Label>
            <Select value={setor} onValueChange={onSetorChange}>
              <SelectTrigger className="mt-1 bg-slate-900 border-slate-700 text-white">
                <SelectValue placeholder="Selecione o setor" />
              </SelectTrigger>
              <SelectContent>
                {SETORES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Filtros de Data */}
        {showDates && onDataInicioChange && onDataFimChange && (
          <>
            <div>
              <Label htmlFor="dataInicio" className="text-slate-300">
                Data Início
              </Label>
              <Input
                id="dataInicio"
                type="date"
                value={dataInicio}
                onChange={(e) => onDataInicioChange(e.target.value)}
                className="mt-1 bg-slate-900 border-slate-700 text-white"
              />
            </div>

            <div>
              <Label htmlFor="dataFim" className="text-slate-300">
                Data Fim
              </Label>
              <Input
                id="dataFim"
                type="date"
                value={dataFim}
                onChange={(e) => onDataFimChange(e.target.value)}
                className="mt-1 bg-slate-900 border-slate-700 text-white"
              />
            </div>
          </>
        )}
      </div>

      {/* Botão Limpar Filtros */}
      <div className="mt-4 flex justify-end">
        <Button
          variant="outline"
          size="sm"
          onClick={onClear}
          className="text-slate-300"
        >
          <X className="w-4 h-4 mr-2" />
          Limpar Filtros
        </Button>
      </div>
    </div>
  );
}
