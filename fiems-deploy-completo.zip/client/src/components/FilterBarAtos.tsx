import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { X } from 'lucide-react';
import type { FiltrosAtos } from '@/hooks/useFilterSortAtos';

interface FilterBarAtosProps {
  filtros: FiltrosAtos;
  handleFilterChange: (key: keyof FiltrosAtos, value: string) => void;
  limparFiltros: () => void;
  tiposDisponiveis: string[];
  orgaosDisponiveis: string[];
  classificacoesDisponiveis: string[];
}

export default function FilterBarAtos({
  filtros,
  handleFilterChange,
  limparFiltros,
  tiposDisponiveis,
  orgaosDisponiveis,
  classificacoesDisponiveis,
}: FilterBarAtosProps) {
  const temFiltrosAtivos = Object.values(filtros).some(v => v !== '');

  return (
    <div className="mt-6 p-6 bg-muted/30 rounded-lg border-2 border-border space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Filtros Avançados</h3>
        {temFiltrosAtivos && (
          <Button
            variant="ghost"
            size="sm"
            onClick={limparFiltros}
            className="gap-2 text-destructive hover:text-destructive"
          >
            <X className="w-4 h-4" />
            Limpar Filtros
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Busca Geral */}
        <div className="space-y-2 lg:col-span-3">
          <Label htmlFor="busca-atos" className="text-sm font-medium">
            Busca Geral
          </Label>
          <Input
            id="busca-atos"
            type="text"
            placeholder="Buscar por ementa, órgão, número..."
            value={filtros.busca}
            onChange={(e) => handleFilterChange('busca', e.target.value)}
            className="w-full"
          />
        </div>

        {/* Tipo de Ato */}
        <div className="space-y-2">
          <Label htmlFor="tipo-ato">Tipo de Ato</Label>
          <Select
            value={filtros.tipo || undefined}
            onValueChange={(value) => handleFilterChange('tipo', value)}
          >
            <SelectTrigger id="tipo-ato">
              <SelectValue placeholder="Todos os tipos" />
            </SelectTrigger>
            <SelectContent>
              {tiposDisponiveis.length > 0 ? (
                tiposDisponiveis.map((tipo) => (
                  <SelectItem key={tipo} value={tipo}>
                    {tipo}
                  </SelectItem>
                ))
              ) : (
                <SelectItem value="none" disabled>Nenhum tipo disponível</SelectItem>
              )}
            </SelectContent>
          </Select>
        </div>

        {/* Grau de Impacto */}
        <div className="space-y-2">
          <Label htmlFor="impacto-ato">Grau de Impacto</Label>
          <Select
            value={filtros.impacto || undefined}
            onValueChange={(value) => handleFilterChange('impacto', value)}
          >
            <SelectTrigger id="impacto-ato">
              <SelectValue placeholder="Todos os impactos" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Alto">Alto</SelectItem>
              <SelectItem value="Médio">Médio</SelectItem>
              <SelectItem value="Baixo">Baixo</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Órgão de Origem */}
        {orgaosDisponiveis.length > 0 && (
          <div className="space-y-2">
            <Label htmlFor="orgao-ato">Órgão de Origem</Label>
            <Select
              value={filtros.orgao || undefined}
              onValueChange={(value) => handleFilterChange('orgao', value)}
            >
              <SelectTrigger id="orgao-ato">
                <SelectValue placeholder="Todos os órgãos" />
              </SelectTrigger>
              <SelectContent>
                {orgaosDisponiveis.map((orgao) => (
                  <SelectItem key={orgao} value={orgao}>
                    {orgao}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Classificação Temática */}
        {classificacoesDisponiveis.length > 0 && (
          <div className="space-y-2">
            <Label htmlFor="classificacao-ato">Classificação Temática</Label>
            <Select
              value={filtros.classificacao || undefined}
              onValueChange={(value) => handleFilterChange('classificacao', value)}
            >
              <SelectTrigger id="classificacao-ato">
                <SelectValue placeholder="Todas as classificações" />
              </SelectTrigger>
              <SelectContent>
                {classificacoesDisponiveis.map((classificacao) => (
                  <SelectItem key={classificacao} value={classificacao}>
                    {classificacao}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Data Início */}
        <div className="space-y-2">
          <Label htmlFor="data-inicio-ato">Data Início</Label>
          <Input
            id="data-inicio-ato"
            type="date"
            value={filtros.dataInicio}
            onChange={(e) => handleFilterChange('dataInicio', e.target.value)}
          />
        </div>

        {/* Data Fim */}
        <div className="space-y-2">
          <Label htmlFor="data-fim-ato">Data Fim</Label>
          <Input
            id="data-fim-ato"
            type="date"
            value={filtros.dataFim}
            onChange={(e) => handleFilterChange('dataFim', e.target.value)}
          />
        </div>
      </div>
    </div>
  );
}
