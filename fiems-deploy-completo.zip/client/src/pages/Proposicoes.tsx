import { useEffect, useState } from 'react';
import { supabase, type Proposicao, type AnaliseImpacto, TABELA_PROPOSICOES, TABELA_ANALISES } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ExternalLink, Calendar, User, FileText, AlertTriangle, CheckCircle2, Info, TrendingUp } from 'lucide-react';
import FilterBar, { type FilterOptions, type SortOptions } from '@/components/FilterBar';
import Breadcrumbs from '@/components/Breadcrumbs';
import { useFilterSort, extrairValoresUnicos, salvarFiltros, carregarFiltros, salvarOrdenacao, carregarOrdenacao } from '@/hooks/useFilterSort';

interface ProposicaoComAnalise extends Proposicao {
  analise?: AnaliseImpacto;
}

export default function Proposicoes() {
  const [proposicoes, setProposicoes] = useState<ProposicaoComAnalise[]>([]);
  const [loading, setLoading] = useState(true);
  const [filtros, setFiltros] = useState<FilterOptions>(() => carregarFiltros('proposicoes'));
  const [ordenacao, setOrdenacao] = useState<SortOptions>(() => 
    carregarOrdenacao('proposicoes') || { campo: 'data', ordem: 'desc' }
  );

  useEffect(() => {
    async function fetchProposicoes() {
      try {
        // Buscar proposições
        const { data: proposicoesData, error: proposicoesError } = await supabase
          .from(TABELA_PROPOSICOES)
          .select('*');

        if (proposicoesError) throw proposicoesError;

        // Buscar análises
        const { data: analisesData, error: analisesError } = await supabase
          .from(TABELA_ANALISES)
          .select('*');

        if (analisesError) console.error('Erro ao carregar análises:', analisesError);

        // Combinar proposições com análises
        const proposicoesComAnalise = (proposicoesData || []).map(prop => {
          const analise = (analisesData || []).find(a => a.proposicao_id === prop.id);
          return { ...prop, analise };
        });

        setProposicoes(proposicoesComAnalise);
      } catch (error) {
        console.error('Erro ao carregar proposições:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchProposicoes();
  }, []);

  // Aplicar filtros e ordenação
  const proposicoesFiltradas = useFilterSort(proposicoes, filtros, ordenacao);

  // Extrair valores únicos para dropdowns
  const tiposDisponiveis = extrairValoresUnicos(proposicoes, 'tipo');
  const autoresDisponiveis = extrairValoresUnicos(proposicoes, 'autor');
  const classificacoesDisponiveis = extrairValoresUnicos(proposicoes, 'classificacao_tematica');

  const handleFilterChange = (novosFiltros: FilterOptions) => {
    setFiltros(novosFiltros);
    salvarFiltros('proposicoes', novosFiltros);
  };

  const handleSortChange = (novaOrdenacao: SortOptions) => {
    setOrdenacao(novaOrdenacao);
    salvarOrdenacao('proposicoes', novaOrdenacao);
  };

  const getImpactColor = (impacto: string) => {
    switch (impacto?.toLowerCase()) {
      case 'alto':
        return 'text-accent bg-accent/10 border-accent/20';
      case 'médio':
        return 'text-primary bg-primary/10 border-primary/20';
      case 'baixo':
        return 'text-secondary bg-secondary/10 border-secondary/20';
      default:
        return 'text-muted-foreground bg-muted border-border';
    }
  };

  const getImpactIcon = (impacto: string) => {
    switch (impacto?.toLowerCase()) {
      case 'alto':
        return <AlertTriangle className="w-4 h-4" />;
      case 'médio':
        return <Info className="w-4 h-4" />;
      case 'baixo':
        return <CheckCircle2 className="w-4 h-4" />;
      default:
        return <Info className="w-4 h-4" />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container max-w-7xl py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-1/3"></div>
            <div className="h-24 bg-muted rounded"></div>
            <div className="grid gap-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-48 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-7xl py-8">
        {/* Breadcrumbs */}
        <Breadcrumbs 
          items={[
            { label: 'Proposições Legislativas' }
          ]} 
        />

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">
            Proposições Legislativas
          </h1>
          <p className="text-muted-foreground">
            Acompanhe todas as proposições legislativas da Assembleia Legislativa de MS
          </p>
        </div>

        {/* Filtros e Ordenação */}
        <FilterBar
          onFilterChange={handleFilterChange}
          onSortChange={handleSortChange}
          resultCount={proposicoesFiltradas.length}
          tiposDisponiveis={tiposDisponiveis}
          autoresDisponiveis={autoresDisponiveis}
          classificacoesDisponiveis={classificacoesDisponiveis}
        />

        {/* Lista de Proposições */}
        <div className="mt-6 space-y-4">
          {proposicoesFiltradas.length === 0 ? (
            <Card className="p-8 text-center">
              <Info className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-semibold mb-2">Nenhuma proposição encontrada</h3>
              <p className="text-muted-foreground">
                Tente ajustar os filtros para ver mais resultados.
              </p>
            </Card>
          ) : (
            proposicoesFiltradas.map((proposicao) => (
              <Card key={proposicao.id} className="card-elevated hover:shadow-lg transition-all duration-200">
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <Badge variant="outline" className="text-sm">
                          {proposicao.tipo}
                        </Badge>
                        {proposicao.sigla && (
                          <Badge variant="outline" className="text-sm font-mono">
                            {proposicao.sigla}
                          </Badge>
                        )}
                        {proposicao.grau_impacto && (
                          <Badge className={`text-sm border ${getImpactColor(proposicao.grau_impacto)}`}>
                            {getImpactIcon(proposicao.grau_impacto)}
                            <span className="ml-1.5">{proposicao.grau_impacto}</span>
                          </Badge>
                        )}
                      </div>
                      <Link href={`/proposicoes/${proposicao.id}`}>
                        <a>
                          <CardTitle className="text-2xl hover:text-primary transition-colors">
                            {proposicao.tipo} {proposicao.numero_real || proposicao.numero}/{proposicao.ano}
                          </CardTitle>
                        </a>
                      </Link>
                      <CardDescription className="mt-2 flex items-center gap-4 text-sm flex-wrap">
                        <span className="flex items-center gap-1.5">
                          <Calendar className="w-4 h-4" />
                          {format(new Date(proposicao.data_apresentacao), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <User className="w-4 h-4" />
                          {proposicao.autor}
                        </span>
                        {proposicao.classificacao_tematica && (
                          <span className="flex items-center gap-1.5">
                            <FileText className="w-4 h-4" />
                            {proposicao.classificacao_tematica}
                          </span>
                        )}
                      </CardDescription>
                    </div>
                    {proposicao.url_origem && (
                      <Button asChild variant="outline" size="sm" className="shrink-0">
                        <a href={proposicao.url_origem} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground leading-relaxed line-clamp-3 mb-4">
                    {proposicao.ementa}
                  </p>

                  {/* Resumo Executivo Preview */}
                  {proposicao.analise?.recomendacao_acao && (
                    <div className={`p-3 rounded-lg border-l-4 mb-4 ${
                      proposicao.grau_impacto === 'Alto' 
                        ? 'border-l-accent bg-accent/5' 
                        : proposicao.grau_impacto === 'Médio' 
                        ? 'border-l-primary bg-primary/5' 
                        : 'border-l-secondary bg-secondary/5'
                    }`}>
                      <div className="flex items-start gap-2">
                        <TrendingUp className="w-4 h-4 mt-0.5 shrink-0 text-muted-foreground" />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-muted-foreground mb-1">Recomendação de Ação</p>
                          <p className="text-sm text-foreground leading-relaxed line-clamp-2">
                            {proposicao.analise.recomendacao_acao}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {proposicao.situacao && (
                        <Badge variant="outline" className="text-xs">
                          {proposicao.situacao}
                        </Badge>
                      )}
                    </div>
                    <Link href={`/proposicoes/${proposicao.id}`}>
                      <a>
                        <Button variant="ghost" size="sm">
                          Ver detalhes →
                        </Button>
                      </a>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Rodapé com estatísticas */}
        {proposicoesFiltradas.length > 0 && (
          <div className="mt-8 p-4 bg-muted/50 rounded-lg">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-foreground">{proposicoesFiltradas.length}</p>
                <p className="text-sm text-muted-foreground">Proposições</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-accent">
                  {proposicoesFiltradas.filter(p => p.grau_impacto === 'Alto').length}
                </p>
                <p className="text-sm text-muted-foreground">Alto Impacto</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-primary">
                  {proposicoesFiltradas.filter(p => p.grau_impacto === 'Médio').length}
                </p>
                <p className="text-sm text-muted-foreground">Médio Impacto</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-secondary">
                  {proposicoesFiltradas.filter(p => p.grau_impacto === 'Baixo').length}
                </p>
                <p className="text-sm text-muted-foreground">Baixo Impacto</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
