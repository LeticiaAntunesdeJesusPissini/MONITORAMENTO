import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, AlertCircle, BarChart3, TrendingUp } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function Dashboard() {
  const [stats, setStats] = useState({
    proposicoes: 0,
    atos: 0,
    alertas: 0,
    analisados: 0
  });

  useEffect(() => {
    async function fetchStats() {
      try {
        const [proposicoesRes, atosRes, alertasRes] = await Promise.all([
          supabase.from('proposicoes_legislativas_2025_11_05_16_31').select('*', { count: 'exact', head: true }),
          supabase.from('atos_executivo_2025_11_05_16_31').select('*', { count: 'exact', head: true }),
          supabase.from('alertas_2025_11_05_16_31').select('*', { count: 'exact', head: true }).eq('lido', false)
        ]);

        setStats({
          proposicoes: proposicoesRes.count || 0,
          atos: atosRes.count || 0,
          alertas: alertasRes.count || 0,
          analisados: (proposicoesRes.count || 0) + (atosRes.count || 0)
        });
      } catch (error) {
        console.error('Erro ao carregar estatísticas:', error);
      }
    }

    fetchStats();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Dashboard</h1>
          <p className="text-gray-600">Visão geral do monitoramento legislativo</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white border-gray-200 hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-700">
                Proposições
              </CardTitle>
              <FileText className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats.proposicoes}</div>
              <p className="text-xs text-gray-500">
                Coletadas da ALEMS
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200 hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-700">
                Atos do Executivo
              </CardTitle>
              <BarChart3 className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats.atos}</div>
              <p className="text-xs text-gray-500">
                Publicados no DOE/MS
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200 hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-700">
                Alertas Ativos
              </CardTitle>
              <AlertCircle className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats.alertas}</div>
              <p className="text-xs text-gray-500">
                Não lidos
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200 hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-700">
                Total Analisado
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats.analisados}</div>
              <p className="text-xs text-gray-500">
                Documentos processados
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <Card className="bg-white border-gray-200">
            <CardHeader>
              <CardTitle className="text-gray-900">Proposições Legislativas</CardTitle>
              <CardDescription className="text-gray-600">
                Monitore projetos de lei e proposições da ALEMS
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/proposicoes">
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                  Ver Proposições
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200">
            <CardHeader>
              <CardTitle className="text-gray-900">Atos do Executivo</CardTitle>
              <CardDescription className="text-gray-600">
                Acompanhe decretos e portarias do DOE/MS
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/atos">
                <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                  Ver Atos
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200">
            <CardHeader>
              <CardTitle className="text-gray-900">Alertas Prioritários</CardTitle>
              <CardDescription className="text-gray-600">
                Documentos de alto impacto para o setor industrial
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/alertas">
                <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
                  Ver Alertas
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <div className="mt-8">
          <Link href="/">
            <Button variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-100">
              ← Voltar para Home
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
