import { useEffect, useState } from 'react';
import { supabase, type AtoExecutivo, type AnaliseImpacto, TABELA_ATOS, TABELA_ANALISES } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calendar, FileText, Building, TrendingUp, ArrowUpDown } from 'lucide-react';
import { useFilterSortAtos } from '@/hooks/useFilterSortAtos';
import FilterBarAtos from '@/components/FilterBarAtos';
import Breadcrumbs from '@/components/Breadcrumbs';

interface AtoComAnalise extends AtoExecutivo {
  analise?: AnaliseImpacto;
  grau_impacto?: string;
}

export default function Atos() {
  const [atos, setAtos] = useState<AtoComAnalise[]>([]);
  const [loading, setLoading] = useState(true);
  const [mostrarFiltros, setMostrarFiltros] = useState(false);

  const {
    filtros,
    ordenacao,
    atosOrdenados,
    handleFilterChange,
    setOrdenacao,
    limparFiltros,
    tiposDisponiveis,
    orgaosDisponiveis,
    classificacoesDisponiveis,
    totalFiltrados,
    totalOriginal,
  } = useFilterSortAtos(atos);

  useEffect(() => {
    async function fetchAtos() {
      try {
        // Buscar atos
        const { data: atosData, error: atosError } = await supabase
          .from(TABELA_ATOS)
          .select('*')
          .order('data_publicacao', { ascending: false });

        if (atosError) throw atosError;

        // Buscar análises
        const { data: analisesData, error: analisesError } = await supabase
          .from(TABELA_ANALISES)
          .select('*');

        if (analisesError) console.error('Erro ao carregar análises:', analisesError);

        // Combinar atos com análises
        const atosComAnalise = (atosData || []).map(ato => {
          const analise = (analisesData || []).find(a => a.ato_executivo_id === ato.id);
          
          // Extrair grau_impacto da análise se disponível
          let grau_impacto = undefined;
          if (analise) {
            if (analise.grau_risco === 'Alto' || analise.grau_oportunidade === 'Alto') {
              grau_impacto = 'Alto';
            } else if (analise.grau_risco === 'Médio' || analise.grau_oportunidade === 'Médio') {
              grau_impacto = 'Médio';
            } else {
              grau_impacto = 'Baixo';
            }
          }
          
          return { ...ato, analise, grau_impacto };
        });

        setAtos(atosComAnalise);
      } catch (error) {
        console.error('Erro ao carregar atos:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchAtos();
  }, []);

  const getImpactoBadge = (impacto?: string) => {
    const configs = {
      'Alto': { bg: 'bg-red-100', text: 'text-red-800', border: 'border-red-300' },
      'Médio': { bg: 'bg-yellow-100', text: 'text-yellow-800', border: 'border-yellow-300' },
      'Baixo': { bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-300' },
    };
    return configs[impacto as keyof typeof configs] || { bg: 'bg-gray-100', text: 'text-gray-800', border: 'border-gray-300' };
  };

  // Estatísticas de impacto
  const estatisticas = {
    total: atosOrdenados.length,
    alto: atosOrdenados.filter(a => a.grau_impacto === 'Alto').length,
    medio: atosOrdenados.filter(a => a.grau_impacto === 'Médio').length,
    baixo: atosOrdenados.filter(a => a.grau_impacto === 'Baixo').length,
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Building className="h-16 w-16 animate-pulse mx-auto mb-4 text-primary" />
          <p className="text-xl text-foreground">Carregando atos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b">
        <div className="container py-6">
          <Breadcrumbs
            items={[
              { label: 'Atos do Executivo', href: '/atos' },
            ]}
          />
          
          <h1 className="text-4xl font-bold mb-2 text-foreground">Atos do Executivo</h1>
          <p className="text-lg text-muted-foreground">
            Monitore decretos, portarias e outros atos publicados no Diário Oficial
          </p>
        </div>
      </div>

      {/* Barra de Filtros e Ordenação */}
      <div className="bg-card border-b">
        <div className="container py-4">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            {/* Botão Filtros */}
            <Button
              variant={mostrarFiltros ? "default" : "outline"}
              onClick={() => setMostrarFiltros(!mostrarFiltros)}
              className="gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>
              </svg>
              Filtros
            </Button>

            <span className="text-sm text-muted-foreground">
              {totalFiltrados} resultado{totalFiltrados !== 1 ? 's' : ''}
            </span>

            {/* Botões de Ordenação */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Ordenar por:</span>
              <Button
                variant={ordenacao.startsWith('data') ? "default" : "outline"}
                size="sm"
                onClick={() => setOrdenacao(ordenacao === 'data-desc' ? 'data-asc' : 'data-desc')}
                className="gap-1"
              >
                <Calendar className="w-4 h-4" />
                Data
                <ArrowUpDown className="w-3 h-3" />
              </Button>
              <Button
                variant={ordenacao.startsWith('numero') ? "default" : "outline"}
                size="sm"
                onClick={() => setOrdenacao(ordenacao === 'numero-desc' ? 'numero-asc' : 'numero-desc')}
                className="gap-1"
              >
                <FileText className="w-4 h-4" />
                Número
                <ArrowUpDown className="w-3 h-3" />
              </Button>
              <Button
                variant={ordenacao.startsWith('impacto') ? "default" : "outline"}
                size="sm"
                onClick={() => setOrdenacao(ordenacao === 'impacto-desc' ? 'impacto-asc' : 'impacto-desc')}
                className="gap-1"
              >
                <TrendingUp className="w-4 h-4" />
                Impacto
                <ArrowUpDown className="w-3 h-3" />
              </Button>
            </div>
          </div>

          {/* Painel de Filtros */}
          {mostrarFiltros && (
            <FilterBarAtos
              filtros={filtros}
              handleFilterChange={handleFilterChange}
              limparFiltros={limparFiltros}
              tiposDisponiveis={tiposDisponiveis.filter((t): t is string => t !== undefined)}
              orgaosDisponiveis={orgaosDisponiveis.filter((o): o is string => o !== undefined)}
              classificacoesDisponiveis={classificacoesDisponiveis.filter((c): c is string => c !== undefined)}
            />
          )}
        </div>
      </div>

      {/* Lista de Atos */}
      <div className="container py-8">
        <div className="space-y-6">
          {atosOrdenados.map((ato) => {
            const impactoConfig = getImpactoBadge(ato.grau_impacto);
            
            return (
              <Link key={ato.id} href={`/atos/${ato.id}`}>
                <Card className="hover:shadow-lg transition-all duration-200 cursor-pointer border-2 hover:border-primary/50">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4 flex-wrap">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                          <Badge variant="outline" className="font-medium">
                            {ato.tipo}
                          </Badge>
                          {ato.grau_impacto && (
                            <Badge className={`${impactoConfig.bg} ${impactoConfig.text} border ${impactoConfig.border}`}>
                              {ato.grau_impacto}
                            </Badge>
                          )}
                        </div>
                        <CardTitle className="text-2xl mb-2 hover:text-primary transition-colors">
                          {ato.tipo} {ato.numero ? `nº ${ato.numero}` : ''}
                          {ato.ano && ` - ${ato.ano}`}
                        </CardTitle>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Metadados */}
                      <div className="flex items-center gap-6 text-sm text-muted-foreground flex-wrap">
                        {ato.data_publicacao && (
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            <span>
                              {format(new Date(ato.data_publicacao), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                            </span>
                          </div>
                        )}
                        {ato.orgao_origem && (
                          <div className="flex items-center gap-2">
                            <Building className="w-4 h-4" />
                            <span>{ato.orgao_origem}</span>
                          </div>
                        )}
                        {ato.classificacao_tematica && (
                          <Badge variant="secondary" className="text-xs">
                            {ato.classificacao_tematica}
                          </Badge>
                        )}
                      </div>

                      {/* Ementa */}
                      <p className="text-base leading-relaxed text-foreground line-clamp-2">
                        {ato.ementa}
                      </p>

                      {/* Resumo Executivo Preview */}
                      {ato.analise?.recomendacao_acao && (
                        <div className={`p-3 rounded-lg border-l-4 ${
                          ato.grau_impacto === 'Alto' 
                            ? 'border-l-red-500 bg-red-50' 
                            : ato.grau_impacto === 'Médio' 
                            ? 'border-l-yellow-500 bg-yellow-50' 
                            : 'border-l-green-500 bg-green-50'
                        }`}>
                          <div className="flex items-start gap-2">
                            <TrendingUp className="w-4 h-4 mt-0.5 shrink-0 text-muted-foreground" />
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-semibold text-muted-foreground mb-1">Recomendação de Ação</p>
                              <p className="text-sm text-foreground leading-relaxed line-clamp-2">
                                {ato.analise.recomendacao_acao}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Status */}
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className="text-xs">
                          {ato.status_analise || 'Analisado'}
                        </Badge>
                        <Button variant="ghost" size="sm" className="gap-2">
                          Ver detalhes →
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>

        {/* Mensagem vazia */}
        {atosOrdenados.length === 0 && (
          <div className="text-center py-16">
            <FileText className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-2xl font-bold mb-2 text-foreground">Nenhum ato encontrado</h3>
            <p className="text-muted-foreground mb-4">Tente ajustar os filtros de busca</p>
            <Button onClick={limparFiltros} variant="outline">
              Limpar Filtros
            </Button>
          </div>
        )}

        {/* Estatísticas */}
        {atosOrdenados.length > 0 && (
          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center p-6 bg-card rounded-lg border">
              <p className="text-4xl font-bold text-foreground mb-2">{estatisticas.total}</p>
              <p className="text-sm text-muted-foreground">Atos Monitorados</p>
            </div>
            <div className="text-center p-6 bg-card rounded-lg border">
              <p className="text-4xl font-bold text-red-600 mb-2">{estatisticas.alto}</p>
              <p className="text-sm text-muted-foreground">Alto Impacto</p>
            </div>
            <div className="text-center p-6 bg-card rounded-lg border">
              <p className="text-4xl font-bold text-yellow-600 mb-2">{estatisticas.medio}</p>
              <p className="text-sm text-muted-foreground">Médio Impacto</p>
            </div>
            <div className="text-center p-6 bg-card rounded-lg border">
              <p className="text-4xl font-bold text-green-600 mb-2">{estatisticas.baixo}</p>
              <p className="text-sm text-muted-foreground">Baixo Impacto</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
