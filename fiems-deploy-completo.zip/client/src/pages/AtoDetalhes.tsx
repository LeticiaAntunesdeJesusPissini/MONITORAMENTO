import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { supabase, TABELA_ATOS, TABELA_ANALISES, type AnaliseImpacto } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import Breadcrumbs from "@/components/Breadcrumbs";
import { 
  ArrowLeft, 
  ExternalLink, 
  Calendar, 
  FileText, 
  Building2, 
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Info,
  Scale,
  Briefcase,
  Shield
} from "lucide-react";

interface Ato {
  id: string;
  numero: string;
  ano: number;
  tipo: string;
  ementa: string;
  data_publicacao: string;
  url_doe?: string;
  orgao_origem?: string;
  classificacao_tematica?: string;
  impacto_fiscal?: boolean;
  texto_completo?: string;
  setores_afetados?: string[];
}

export default function AtoDetalhes() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const [ato, setAto] = useState<Ato | null>(null);
  const [analise, setAnalise] = useState<AnaliseImpacto | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchAto() {
      try {
        const { data, error } = await supabase
          .from(TABELA_ATOS)
          .select('*')
          .eq('id', id)
          .single();

        if (error) throw error;
        setAto(data);

        // Buscar análise de impacto
        const { data: analiseData, error: analiseError } = await supabase
          .from(TABELA_ANALISES)
          .select('*')
          .eq('ato_executivo_id', id)
          .single();

        if (!analiseError && analiseData) {
          setAnalise(analiseData);
        }
      } catch (error) {
        console.error('Erro ao carregar ato:', error);
      } finally {
        setLoading(false);
      }
    }

    if (id) {
      fetchAto();
    }
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container max-w-6xl py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-4 bg-muted rounded w-1/4"></div>
            <div className="h-12 bg-muted rounded w-1/2"></div>
            <div className="h-64 bg-muted rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!ato) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container max-w-6xl py-8">
          <Button onClick={() => setLocation('/atos')} variant="outline" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
          <Card className="p-8 text-center">
            <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-destructive" />
            <h2 className="text-xl font-semibold mb-2">Ato não encontrado</h2>
            <p className="text-muted-foreground">O ato que você está procurando não existe ou foi removido.</p>
          </Card>
        </div>
      </div>
    );
  }

  const getImpactColor = (impacto: string) => {
    switch (impacto?.toLowerCase()) {
      case 'alto':
        return 'text-accent bg-accent/10 border-accent/20';
      case 'médio':
        return 'text-primary bg-primary/10 border-primary/20';
      case 'baixo':
        return 'text-secondary bg-secondary/10 border-secondary/20';
      default:
        return 'text-muted-foreground bg-muted border-border';
    }
  };

  const getImpactIcon = (impacto: string) => {
    switch (impacto?.toLowerCase()) {
      case 'alto':
        return <AlertTriangle className="w-5 h-5" />;
      case 'médio':
        return <Info className="w-5 h-5" />;
      case 'baixo':
        return <CheckCircle2 className="w-5 h-5" />;
      default:
        return <Info className="w-5 h-5" />;
    }
  };

  // Determinar grau de impacto baseado na análise
  const grauImpacto = analise?.impacto_tributario?.nivel || 
                      analise?.impacto_empresarial?.nivel || 
                      'Baixo';

  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-6xl py-8">
        {/* Breadcrumbs */}
        <Breadcrumbs 
          items={[
            { label: 'Atos do Executivo', href: '/atos' },
            { label: `${ato.tipo} ${ato.numero}/${ato.ano}` }
          ]} 
        />

        {/* Header */}
        <div className="mb-8">
          <div className="flex items-start justify-between mb-4 gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-3">
                <Badge variant="outline" className="text-sm">
                  {ato.tipo}
                </Badge>
                {ato.impacto_fiscal && (
                  <Badge className="badge-warning text-sm">
                    <Shield className="w-4 h-4 mr-1" />
                    Impacto Fiscal
                  </Badge>
                )}
                {analise && (
                  <Badge className={`text-sm border ${getImpactColor(grauImpacto)}`}>
                    {getImpactIcon(grauImpacto)}
                    <span className="ml-1.5">Impacto {grauImpacto}</span>
                  </Badge>
                )}
              </div>
              <h1 className="text-4xl font-bold text-foreground mb-4">
                {ato.tipo} nº {ato.numero}/{ato.ano}
              </h1>
              <div className="flex items-center gap-6 text-muted-foreground flex-wrap">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm">{new Date(ato.data_publicacao).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}</span>
                </div>
                {ato.orgao_origem && (
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4" />
                    <span className="text-sm">{ato.orgao_origem}</span>
                  </div>
                )}
              </div>
            </div>
            {ato.url_doe && (
              <Button asChild className="shrink-0">
                <a href={ato.url_doe} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Ver no DOE
                </a>
              </Button>
            )}
          </div>
        </div>

        {/* RESUMO EXECUTIVO - DESTAQUE */}
        {analise && (
          <Card className={`mb-8 border-l-4 ${
            grauImpacto === 'Alto' 
              ? 'border-l-accent bg-accent/5' 
              : grauImpacto === 'Médio' 
              ? 'border-l-primary bg-primary/5' 
              : 'border-l-secondary bg-secondary/5'
          }`}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-2xl">
                <TrendingUp className="w-6 h-6" />
                Resumo Executivo
              </CardTitle>
              <CardDescription>
                Análise de impacto para o setor industrial de Mato Grosso do Sul
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Recomendação de Ação */}
              <div className="p-4 rounded-lg bg-card border">
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-secondary" />
                  Recomendação de Ação
                </h3>
                <p className="text-foreground leading-relaxed">
                  {analise.recomendacao_acao}
                </p>
              </div>

              {/* Métricas de Impacto */}
              <div className="grid md:grid-cols-3 gap-4">
                {analise.impacto_tributario && (
                  <div className="p-4 rounded-lg bg-card border card-elevated">
                    <div className="flex items-center gap-2 mb-2">
                      <Scale className="w-5 h-5 text-primary" />
                      <p className="font-semibold text-sm">Impacto Tributário</p>
                    </div>
                    <Badge className={`mb-2 ${getImpactColor(analise.impacto_tributario.nivel)}`}>
                      {analise.impacto_tributario.nivel}
                    </Badge>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {analise.impacto_tributario.descricao}
                    </p>
                  </div>
                )}
                {analise.impacto_empresarial && (
                  <div className="p-4 rounded-lg bg-card border card-elevated">
                    <div className="flex items-center gap-2 mb-2">
                      <Building2 className="w-5 h-5 text-primary" />
                      <p className="font-semibold text-sm">Impacto Empresarial</p>
                    </div>
                    <Badge className={`mb-2 ${getImpactColor(analise.impacto_empresarial.nivel)}`}>
                      {analise.impacto_empresarial.nivel}
                    </Badge>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {analise.impacto_empresarial.descricao}
                    </p>
                  </div>
                )}
                {analise.grau_risco && (
                  <div className="p-4 rounded-lg bg-card border card-elevated">
                    <div className="flex items-center gap-2 mb-2">
                      <Briefcase className="w-5 h-5 text-primary" />
                      <p className="font-semibold text-sm">Grau de Risco</p>
                    </div>
                    <Badge className={`mb-2 ${getImpactColor(analise.grau_risco)}`}>
                      {analise.grau_risco}
                    </Badge>
                    {analise.justificativa && (
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        {analise.justificativa.substring(0, 120)}...
                      </p>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Coluna Principal */}
          <div className="lg:col-span-2 space-y-6">
            {/* Ementa */}
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Ementa
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground leading-relaxed">
                  {ato.ementa}
                </p>
              </CardContent>
            </Card>

            {/* Texto Completo */}
            {ato.texto_completo && (
              <Card className="card-elevated">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Texto Completo
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="prose prose-sm max-w-none">
                    <pre className="whitespace-pre-wrap text-sm text-foreground leading-relaxed font-sans">
                      {ato.texto_completo}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Coluna Lateral */}
          <div className="space-y-6">
            {/* Informações */}
            <Card className="card-elevated">
              <CardHeader>
                <CardTitle className="text-lg">Informações</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {ato.orgao_origem && (
                  <>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Órgão de Origem</p>
                      <p className="text-sm font-medium">{ato.orgao_origem}</p>
                    </div>
                    <Separator />
                  </>
                )}
                {ato.classificacao_tematica && (
                  <>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Classificação Temática</p>
                      <p className="text-sm font-medium">{ato.classificacao_tematica}</p>
                    </div>
                    <Separator />
                  </>
                )}
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Data de Publicação</p>
                  <p className="text-sm font-medium">
                    {new Date(ato.data_publicacao).toLocaleDateString('pt-BR', { 
                      day: '2-digit', 
                      month: 'long', 
                      year: 'numeric' 
                    })}
                  </p>
                </div>
                {ato.impacto_fiscal !== undefined && (
                  <>
                    <Separator />
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Impacto Fiscal</p>
                      <Badge className={ato.impacto_fiscal ? 'badge-warning' : 'badge-info'}>
                        {ato.impacto_fiscal ? 'Sim' : 'Não'}
                      </Badge>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Setores Afetados */}
            {ato.setores_afetados && ato.setores_afetados.length > 0 && (
              <Card className="card-elevated">
                <CardHeader>
                  <CardTitle className="text-lg">Setores Afetados</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {ato.setores_afetados.map((setor, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {setor}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Análise Detalhada */}
            {analise && (
              <Card className="card-elevated">
                <CardHeader>
                  <CardTitle className="text-lg">Análise Detalhada</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {analise.impacto_economico && (
                    <>
                      <div>
                        <p className="text-sm font-semibold mb-1">Impacto Econômico</p>
                        <Badge className={`mb-2 text-xs ${getImpactColor(analise.impacto_economico.nivel)}`}>
                          {analise.impacto_economico.nivel}
                        </Badge>
                        <p className="text-xs text-muted-foreground leading-relaxed">
                          {analise.impacto_economico.descricao}
                        </p>
                      </div>
                      <Separator />
                    </>
                  )}
                  {analise.grau_oportunidade && (
                    <div>
                      <p className="text-sm font-semibold mb-1">Grau de Oportunidade</p>
                      <Badge className={`text-xs ${getImpactColor(analise.grau_oportunidade)}`}>
                        {analise.grau_oportunidade}
                      </Badge>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Botão de voltar no final */}
        <div className="mt-8">
          <Button onClick={() => setLocation('/atos')} variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar para Atos do Executivo
          </Button>
        </div>
      </div>
    </div>
  );
}
