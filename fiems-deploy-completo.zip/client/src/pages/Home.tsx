import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, BarChart3, Bell, ArrowRight, TrendingUp, Shield } from 'lucide-react';

// Paleta de cores Sherwin-Williams
const CORES = {
  indigo: '#1F3A5F',
  jacarandaMimoso: '#7FA8C4',
  baiaTodosSantos: '#2B5F75',
  confinsCeu: '#C4D7E0',
  orvalhoEstrelas: '#A8B5B2',
  silencioNoite: '#6B8A99',
  frescorIrresistivel: '#D4E5C7',
  neblinaPerene: '#8B9A8A'
};

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="text-white" style={{ background: `linear-gradient(135deg, ${CORES.indigo} 0%, ${CORES.baiaTodosSantos} 50%, ${CORES.jacarandaMimoso} 100%)` }}>
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Monitoramento Legislativo
            </h1>
            <p className="text-xl md:text-2xl mb-4" style={{ color: CORES.confinsCeu }}>
              FIEMS - Federação das Indústrias de Mato Grosso do Sul
            </p>
            <p className="text-lg mb-8 max-w-2xl mx-auto" style={{ color: CORES.confinsCeu }}>
              Acompanhe em tempo real proposições legislativas e atos do executivo que impactam o setor industrial de MS
            </p>
            <Link href="/dashboard">
              <Button size="lg" className="text-lg px-8 py-6 h-auto" style={{ backgroundColor: 'white', color: CORES.indigo }}>
                Acessar Dashboard Completo
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="container mx-auto px-4 -mt-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          <Card className="shadow-xl border-0" style={{ backgroundColor: CORES.confinsCeu }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg" style={{ backgroundColor: 'white' }}>
                  <FileText className="h-8 w-8" style={{ color: CORES.jacarandaMimoso }} />
                </div>
                <TrendingUp className="h-6 w-6" style={{ color: CORES.frescorIrresistivel }} />
              </div>
              <h3 className="text-3xl font-bold mb-1" style={{ color: CORES.indigo }}>44</h3>
              <p style={{ color: CORES.silencioNoite }}>Proposições Legislativas</p>
            </CardContent>
          </Card>

          <Card className="shadow-xl border-0" style={{ backgroundColor: CORES.confinsCeu }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg" style={{ backgroundColor: 'white' }}>
                  <BarChart3 className="h-8 w-8" style={{ color: CORES.frescorIrresistivel }} />
                </div>
                <TrendingUp className="h-6 w-6" style={{ color: CORES.frescorIrresistivel }} />
              </div>
              <h3 className="text-3xl font-bold mb-1" style={{ color: CORES.indigo }}>25</h3>
              <p style={{ color: CORES.silencioNoite }}>Atos do Executivo</p>
            </CardContent>
          </Card>

          <Card className="shadow-xl border-0" style={{ backgroundColor: CORES.confinsCeu }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg" style={{ backgroundColor: 'white' }}>
                  <Shield className="h-8 w-8" style={{ color: '#f59e0b' }} />
                </div>
                <TrendingUp className="h-6 w-6" style={{ color: CORES.frescorIrresistivel }} />
              </div>
              <h3 className="text-3xl font-bold mb-1" style={{ color: CORES.indigo }}>69</h3>
              <p style={{ color: CORES.silencioNoite }}>Documentos Monitorados</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main Cards Section */}
      <div className="container mx-auto px-4 pb-16">
        <h2 className="text-3xl font-bold text-center mb-12" style={{ color: CORES.indigo }}>
          Acesse as Informações
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Proposições Card */}
          <Link href="/proposicoes">
            <Card className="h-full hover:shadow-2xl transition-all duration-300 cursor-pointer border-2" style={{ backgroundColor: 'white', borderColor: CORES.confinsCeu }}>
              <CardHeader>
                <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto" style={{ backgroundColor: CORES.jacarandaMimoso }}>
                  <FileText className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-2xl text-center mb-2" style={{ color: CORES.indigo }}>
                  Proposições ALEMS
                </CardTitle>
                <CardDescription className="text-center" style={{ color: CORES.silencioNoite }}>
                  Acompanhe todas as proposições legislativas da Assembleia Legislativa de MS
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 mb-6" style={{ color: CORES.indigo }}>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>44 proposições em tramitação</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Filtros por tema e impacto</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Links para fontes oficiais</span>
                  </li>
                </ul>
                <Button className="w-full" style={{ backgroundColor: CORES.jacarandaMimoso, color: 'white' }}>
                  Ver Proposições
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </Link>

          {/* Atos Card */}
          <Link href="/atos">
            <Card className="h-full hover:shadow-2xl transition-all duration-300 cursor-pointer border-2" style={{ backgroundColor: 'white', borderColor: CORES.confinsCeu }}>
              <CardHeader>
                <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto" style={{ backgroundColor: CORES.frescorIrresistivel }}>
                  <BarChart3 className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-2xl text-center mb-2" style={{ color: CORES.indigo }}>
                  Atos do Executivo
                </CardTitle>
                <CardDescription className="text-center" style={{ color: CORES.silencioNoite }}>
                  Monitore decretos, portarias e outros atos publicados no Diário Oficial
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 mb-6" style={{ color: CORES.indigo }}>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>25 atos executivos catalogados</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Histórico desde 2003</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Análise de impacto industrial</span>
                  </li>
                </ul>
                <Button className="w-full" style={{ backgroundColor: CORES.frescorIrresistivel, color: 'white' }}>
                  Ver Atos
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </Link>

          {/* Alertas Card */}
          <Link href="/alertas">
            <Card className="h-full hover:shadow-2xl transition-all duration-300 cursor-pointer border-2" style={{ backgroundColor: 'white', borderColor: CORES.confinsCeu }}>
              <CardHeader>
                <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto" style={{ backgroundColor: '#f59e0b' }}>
                  <Bell className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-2xl text-center mb-2" style={{ color: CORES.indigo }}>
                  Alertas Prioritários
                </CardTitle>
                <CardDescription className="text-center" style={{ color: CORES.silencioNoite }}>
                  Receba notificações sobre documentos de alto impacto para o setor industrial
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 mb-6" style={{ color: CORES.indigo }}>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Classificação automática</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Documentos de alto impacto</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Acompanhamento prioritário</span>
                  </li>
                </ul>
                <Button className="w-full" style={{ backgroundColor: '#f59e0b', color: 'white' }}>
                  Ver Alertas
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>

      {/* About Section */}
      <div className="py-16" style={{ backgroundColor: CORES.confinsCeu }}>
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6" style={{ color: CORES.indigo }}>
              Sobre o Sistema
            </h2>
            <p className="text-lg mb-4 leading-relaxed" style={{ color: CORES.indigo }}>
              Este sistema utiliza tecnologia avançada para coletar, analisar e classificar automaticamente proposições legislativas da ALEMS e atos do executivo publicados no DOE/MS.
            </p>
            <p className="text-lg leading-relaxed" style={{ color: CORES.indigo }}>
              Com análise de impacto por setor industrial, classificação temática e geração de alertas prioritários, a FIEMS pode acompanhar de forma eficiente toda a atividade legislativa e regulatória que afeta o setor industrial de Mato Grosso do Sul.
            </p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="py-8 text-white" style={{ backgroundColor: CORES.indigo }}>
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm" style={{ color: CORES.confinsCeu }}>
            Sistema de Monitoramento Legislativo - FIEMS © 2025
          </p>
        </div>
      </footer>
    </div>
  );
}
