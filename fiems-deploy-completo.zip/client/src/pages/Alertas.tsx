import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { AlertTriangle, TrendingUp, ArrowLeft, FileText, Calendar, User, Building2 } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

// Paleta de cores Sherwin-Williams
const CORES = {
  indigo: '#1F3A5F',
  jacarandaMimoso: '#7FA8C4',
  baiaTodosSantos: '#2B5F75',
  confinsCeu: '#C4D7E0',
  orvalhoEstrelas: '#A8B5B2',
  silencioNoite: '#6B8A99',
  frescorIrresistivel: '#D4E5C7',
  neblinaPerene: '#8B9A8A'
};

interface DocumentoAlerta {
  id: string;
  tipo: 'proposicao' | 'ato';
  numero?: string;
  ano: number;
  tipo_documento: string;
  ementa: string;
  autor?: string;
  orgao_origem?: string;
  data: string;
  grau_impacto?: string;
  classificacao_tematica?: string;
  prioridade: 'ALTA' | 'MÉDIA' | 'BAIXA';
  motivo: string;
}

export default function Alertas() {
  const [alertas, setAlertas] = useState<DocumentoAlerta[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchAlertas() {
      try {
        // Buscar proposições de alto impacto
        const { data: proposicoes, error: errorProp } = await supabase
          .from('proposicoes_legislativas_2025_11_05_16_31')
          .select('*')
          .order('data_apresentacao', { ascending: false });

        if (errorProp) throw errorProp;

        // Buscar atos executivos recentes
        const { data: atos, error: errorAtos } = await supabase
          .from('atos_executivo_2025_11_05_16_31')
          .select('*')
          .order('data_publicacao', { ascending: false });

        if (errorAtos) throw errorAtos;

        // Processar alertas
        const alertasProcessados: DocumentoAlerta[] = [];

        // Proposições de alto impacto
        proposicoes?.forEach((prop: any) => {
          if (prop.grau_impacto === 'Alto') {
            alertasProcessados.push({
              id: prop.id,
              tipo: 'proposicao',
              numero: prop.numero,
              ano: prop.ano,
              tipo_documento: prop.tipo,
              ementa: prop.ementa,
              autor: prop.autor,
              data: prop.data_apresentacao,
              grau_impacto: prop.grau_impacto,
              classificacao_tematica: prop.classificacao_tematica,
              prioridade: 'ALTA',
              motivo: 'Proposição classificada com ALTO IMPACTO para o setor industrial'
            });
          }
        });

        // Proposições recentes (últimos 7 dias)
        const seteDiasAtras = new Date();
        seteDiasAtras.setDate(seteDiasAtras.getDate() - 7);

        proposicoes?.forEach((prop: any) => {
          const dataApresentacao = new Date(prop.data_apresentacao);
          if (dataApresentacao >= seteDiasAtras && prop.grau_impacto !== 'Alto') {
            alertasProcessados.push({
              id: prop.id,
              tipo: 'proposicao',
              numero: prop.numero,
              ano: prop.ano,
              tipo_documento: prop.tipo,
              ementa: prop.ementa,
              autor: prop.autor,
              data: prop.data_apresentacao,
              grau_impacto: prop.grau_impacto,
              classificacao_tematica: prop.classificacao_tematica,
              prioridade: 'MÉDIA',
              motivo: 'Proposição apresentada recentemente (últimos 7 dias)'
            });
          }
        });

        // Atos executivos recentes com impacto fiscal
        atos?.forEach((ato: any) => {
          if (ato.impacto_fiscal === true) {
            alertasProcessados.push({
              id: ato.id,
              tipo: 'ato',
              numero: ato.numero,
              ano: ato.ano,
              tipo_documento: ato.tipo,
              ementa: ato.ementa,
              orgao_origem: ato.orgao_origem,
              data: ato.data_publicacao,
              classificacao_tematica: ato.classificacao_tematica,
              prioridade: 'ALTA',
              motivo: 'Ato executivo com IMPACTO FISCAL identificado'
            });
          }
        });

        // Atos de 2024 e 2025 (mais recentes)
        atos?.forEach((ato: any) => {
          if ((ato.ano === 2024 || ato.ano === 2025) && ato.impacto_fiscal !== true) {
            alertasProcessados.push({
              id: ato.id,
              tipo: 'ato',
              numero: ato.numero,
              ano: ato.ano,
              tipo_documento: ato.tipo,
              ementa: ato.ementa,
              orgao_origem: ato.orgao_origem,
              data: ato.data_publicacao,
              classificacao_tematica: ato.classificacao_tematica,
              prioridade: 'BAIXA',
              motivo: 'Ato executivo recente publicado no DOE/MS'
            });
          }
        });

        // Ordenar por prioridade e data
        alertasProcessados.sort((a, b) => {
          const prioridadeOrdem = { 'ALTA': 0, 'MÉDIA': 1, 'BAIXA': 2 };
          if (prioridadeOrdem[a.prioridade] !== prioridadeOrdem[b.prioridade]) {
            return prioridadeOrdem[a.prioridade] - prioridadeOrdem[b.prioridade];
          }
          return new Date(b.data).getTime() - new Date(a.data).getTime();
        });

        setAlertas(alertasProcessados);
      } catch (error) {
        console.error('Erro ao carregar alertas:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchAlertas();
  }, []);

  const getPrioridadeColor = (prioridade: string) => {
    const colors = {
      'ALTA': '#f59e0b',
      'MÉDIA': CORES.jacarandaMimoso,
      'BAIXA': CORES.frescorIrresistivel
    };
    return colors[prioridade as keyof typeof colors] || CORES.silencioNoite;
  };

  const getPrioridadeIcon = (prioridade: string) => {
    if (prioridade === 'ALTA') {
      return <AlertTriangle className="w-5 h-5" style={{ color: '#f59e0b' }} />;
    }
    return <TrendingUp className="w-5 h-5" style={{ color: CORES.jacarandaMimoso }} />;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="h-16 w-16 animate-pulse mx-auto mb-4" style={{ color: CORES.jacarandaMimoso }} />
          <p className="text-xl" style={{ color: CORES.indigo }}>Carregando alertas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b" style={{ borderColor: CORES.confinsCeu }}>
        <div className="container mx-auto px-4 py-6">
          <Link href="/">
            <Button variant="outline" className="mb-4" style={{ borderColor: CORES.confinsCeu, color: CORES.indigo }}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </Link>
          
          <h1 className="text-4xl font-bold mb-2" style={{ color: CORES.indigo }}>Alertas Prioritários</h1>
          <p className="text-lg mb-2" style={{ color: CORES.silencioNoite }}>
            {alertas.length} alertas identificados
          </p>
          <div className="flex gap-4 flex-wrap">
            <Badge style={{ backgroundColor: '#f59e0b', color: 'white' }}>
              {alertas.filter(a => a.prioridade === 'ALTA').length} Alta Prioridade
            </Badge>
            <Badge style={{ backgroundColor: CORES.jacarandaMimoso, color: 'white' }}>
              {alertas.filter(a => a.prioridade === 'MÉDIA').length} Média Prioridade
            </Badge>
            <Badge style={{ backgroundColor: CORES.frescorIrresistivel, color: 'white' }}>
              {alertas.filter(a => a.prioridade === 'BAIXA').length} Baixa Prioridade
            </Badge>
          </div>
        </div>
      </div>

      {/* Lista de Alertas */}
      <div className="container mx-auto px-4 py-8">
        <div className="space-y-6">
          {alertas.map((alerta) => (
            <Link key={`${alerta.tipo}-${alerta.id}`} href={alerta.tipo === 'proposicao' ? `/proposicoes/${alerta.id}` : `/atos/${alerta.id}`}>
              <Card className="hover:shadow-xl transition-all duration-300 cursor-pointer border-2" style={{ borderColor: CORES.confinsCeu, backgroundColor: 'white' }}>
                <CardHeader>
                  <div className="flex items-start justify-between gap-4 flex-wrap">
                    <div className="flex items-start gap-3 flex-1">
                      {getPrioridadeIcon(alerta.prioridade)}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                          <Badge style={{ backgroundColor: getPrioridadeColor(alerta.prioridade), color: 'white' }}>
                            {alerta.prioridade}
                          </Badge>
                          <Badge variant="outline" style={{ borderColor: CORES.baiaTodosSantos, color: CORES.baiaTodosSantos }}>
                            {alerta.tipo === 'proposicao' ? 'Proposição' : 'Ato Executivo'}
                          </Badge>
                          {alerta.classificacao_tematica && (
                            <Badge variant="outline" style={{ borderColor: CORES.silencioNoite, color: CORES.silencioNoite }}>
                              {alerta.classificacao_tematica}
                            </Badge>
                          )}
                        </div>
                        <CardTitle className="text-2xl mb-2" style={{ color: CORES.indigo }}>
                          {alerta.tipo_documento} {alerta.numero ? `${alerta.numero}/${alerta.ano}` : alerta.ano}
                        </CardTitle>
                        <CardDescription className="text-base mb-3" style={{ color: CORES.silencioNoite }}>
                          {alerta.motivo}
                        </CardDescription>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-base mb-4 leading-relaxed" style={{ color: CORES.indigo }}>
                    {alerta.ementa}
                  </p>
                  <div className="flex items-center gap-6 text-sm flex-wrap" style={{ color: CORES.silencioNoite }}>
                    {alerta.autor && (
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        <span>{alerta.autor}</span>
                      </div>
                    )}
                    {alerta.orgao_origem && (
                      <div className="flex items-center gap-2">
                        <Building2 className="w-4 h-4" />
                        <span>{alerta.orgao_origem}</span>
                      </div>
                    )}
                    {alerta.data && (
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>
                          {format(new Date(alerta.data), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                        </span>
                      </div>
                    )}
                    {alerta.grau_impacto && (
                      <Badge variant="secondary" style={{ 
                        backgroundColor: alerta.grau_impacto === 'Alto' ? '#f59e0b' : CORES.confinsCeu,
                        color: alerta.grau_impacto === 'Alto' ? 'white' : CORES.indigo
                      }}>
                        Impacto: {alerta.grau_impacto}
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {alertas.length === 0 && (
          <div className="text-center py-16">
            <FileText className="h-16 w-16 mx-auto mb-4" style={{ color: CORES.orvalhoEstrelas }} />
            <h3 className="text-2xl font-bold mb-2" style={{ color: CORES.indigo }}>Nenhum alerta encontrado</h3>
            <p style={{ color: CORES.silencioNoite }}>Não há documentos prioritários no momento</p>
          </div>
        )}
      </div>
    </div>
  );
}
