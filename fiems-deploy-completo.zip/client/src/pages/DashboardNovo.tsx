import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { FileText, TrendingUp, AlertTriangle, Download, ArrowLeft, BarChart3 } from "lucide-react";

interface DashboardStats {
  totalProposicoes: number;
  totalAtos: number;
  proposicoesPorTema: { tema: string; quantidade: number }[];
  proposicoesPorImpacto: { impacto: string; quantidade: number }[];
  atosPorAno: { ano: number; quantidade: number }[];
  proposicoesPorData: { data: string; quantidade: number }[];
}

// Paleta de cores Sherwin-Williams personalizada
const PALETA_CORES = {
  jacarandaMimoso: '#7FA8C4',      // SW 6802 - Azul claro
  baiaTodosSantos: '#2B5F75',      // SW 6509 - Azul petróleo
  indigo: '#1F3A5F',               // SW 6531 - Azul escuro
  confinsCeu: '#C4D7E0',           // SW 6239 - Azul muito claro
  orvalhoEstrelas: '#A8B5B2',      // SW 9138 - Cinza claro
  silencioNoite: '#6B8A99',        // SW 9148 - Azul acinzentado
  frescorIrresistivel: '#D4E5C7',  // SW 6428 - Verde claro
  neblinaPerene: '#8B9A8A'         // SW 9130 - Cinza esverdeado
};

export default function DashboardNovo() {
  const [stats, setStats] = useState<DashboardStats>({
    totalProposicoes: 0,
    totalAtos: 0,
    proposicoesPorTema: [],
    proposicoesPorImpacto: [],
    atosPorAno: [],
    proposicoesPorData: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchStats() {
      try {
        const { data: proposicoes, error: propError } = await supabase
          .from('proposicoes_legislativas_2025_11_05_16_31')
          .select('*');

        if (propError) throw propError;

        const { data: atos, error: atosError } = await supabase
          .from('atos_executivo_2025_11_05_16_31')
          .select('*');

        if (atosError) throw atosError;

        const temaCount: Record<string, number> = {};
        const impactoCount: Record<string, number> = {};
        const dataCount: Record<string, number> = {};

        proposicoes?.forEach(prop => {
          const tema = prop.classificacao_tematica || 'Outros';
          temaCount[tema] = (temaCount[tema] || 0) + 1;

          const impacto = prop.grau_impacto || 'Não classificado';
          impactoCount[impacto] = (impactoCount[impacto] || 0) + 1;

          if (prop.data_apresentacao) {
            const data = new Date(prop.data_apresentacao).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
            dataCount[data] = (dataCount[data] || 0) + 1;
          }
        });

        const anoCount: Record<number, number> = {};
        atos?.forEach(ato => {
          anoCount[ato.ano] = (anoCount[ato.ano] || 0) + 1;
        });

        setStats({
          totalProposicoes: proposicoes?.length || 0,
          totalAtos: atos?.length || 0,
          proposicoesPorTema: Object.entries(temaCount)
            .map(([tema, quantidade]) => ({ tema, quantidade }))
            .sort((a, b) => b.quantidade - a.quantidade)
            .slice(0, 6),
          proposicoesPorImpacto: Object.entries(impactoCount)
            .map(([impacto, quantidade]) => ({ impacto, quantidade })),
          atosPorAno: Object.entries(anoCount)
            .map(([ano, quantidade]) => ({ ano: Number(ano), quantidade }))
            .sort((a, b) => a.ano - b.ano),
          proposicoesPorData: Object.entries(dataCount)
            .map(([data, quantidade]) => ({ data, quantidade }))
            .slice(0, 10)
        });
      } catch (error) {
        console.error('Erro ao carregar estatísticas:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <BarChart3 className="h-16 w-16 text-gray-400 animate-pulse mx-auto mb-4" />
          <p className="text-xl text-gray-600">Carregando dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-4">
            <Link href="/">
              <Button variant="outline" className="border-gray-300">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <Button variant="outline" className="border-gray-300">
              <Download className="w-4 h-4 mr-2" />
              Exportar Relatório
            </Button>
          </div>
          
          <h1 className="text-4xl font-bold mb-2" style={{ color: '#1F3A5F' }}>Dashboard Analítico</h1>
          <p className="text-lg" style={{ color: '#1F3A5F' }}>
            Visão geral do monitoramento legislativo
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Cards de Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-0 shadow-lg" style={{ backgroundColor: PALETA_CORES.confinsCeu }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg" style={{ backgroundColor: PALETA_CORES.jacarandaMimoso }}>
                  <FileText className="h-8 w-8 text-white" />
                </div>
                <TrendingUp className="h-6 w-6" style={{ color: PALETA_CORES.baiaTodosSantos }} />
              </div>
              <h3 className="text-3xl font-bold mb-1" style={{ color: PALETA_CORES.indigo }}>{stats.totalProposicoes}</h3>
              <p className="text-gray-700">Proposições Legislativas</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg" style={{ backgroundColor: PALETA_CORES.frescorIrresistivel }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg" style={{ backgroundColor: PALETA_CORES.neblinaPerene }}>
                  <BarChart3 className="h-8 w-8 text-white" />
                </div>
                <TrendingUp className="h-6 w-6" style={{ color: PALETA_CORES.neblinaPerene }} />
              </div>
              <h3 className="text-3xl font-bold mb-1" style={{ color: PALETA_CORES.indigo }}>{stats.totalAtos}</h3>
              <p className="text-gray-700">Atos do Executivo</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg" style={{ backgroundColor: PALETA_CORES.orvalhoEstrelas }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg" style={{ backgroundColor: PALETA_CORES.silencioNoite }}>
                  <AlertTriangle className="h-8 w-8 text-white" />
                </div>
              </div>
              <h3 className="text-3xl font-bold mb-1" style={{ color: PALETA_CORES.indigo }}>{stats.totalProposicoes + stats.totalAtos}</h3>
              <p className="text-gray-700">Documentos Monitorados</p>
            </CardContent>
          </Card>
        </div>

        {/* Gráficos */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Proposições por Tema */}
          <Card className="border-0 shadow-lg bg-white">
            <CardHeader className="border-b bg-gray-50">
              <CardTitle className="text-2xl text-gray-900">Proposições por Tema</CardTitle>
              <CardDescription>Distribuição por classificação temática</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={stats.proposicoesPorTema}>
                  <CartesianGrid strokeDasharray="3 3" stroke={PALETA_CORES.confinsCeu} />
                  <XAxis dataKey="tema" tick={{ fill: PALETA_CORES.indigo }} />
                  <YAxis tick={{ fill: PALETA_CORES.indigo }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: `2px solid ${PALETA_CORES.confinsCeu}`,
                      borderRadius: '8px'
                    }} 
                  />
                  <Bar dataKey="quantidade" fill={PALETA_CORES.jacarandaMimoso} radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Proposições por Impacto */}
          <Card className="border-0 shadow-lg bg-white">
            <CardHeader className="border-b bg-gray-50">
              <CardTitle className="text-2xl text-gray-900">Grau de Impacto</CardTitle>
              <CardDescription>Distribuição por nível de impacto</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={stats.proposicoesPorImpacto}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ impacto, percent }) => `${impacto}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill={PALETA_CORES.jacarandaMimoso}
                    dataKey="quantidade"
                  >
                    {stats.proposicoesPorImpacto.map((entry, index) => {
                      const cores = [
                        PALETA_CORES.baiaTodosSantos,
                        PALETA_CORES.jacarandaMimoso,
                        PALETA_CORES.silencioNoite,
                        PALETA_CORES.neblinaPerene
                      ];
                      return <Cell key={`cell-${index}`} fill={cores[index % cores.length]} />;
                    })}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: `2px solid ${PALETA_CORES.confinsCeu}`,
                      borderRadius: '8px'
                    }} 
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Atos por Ano */}
          <Card className="border-0 shadow-lg bg-white">
            <CardHeader className="border-b bg-gray-50">
              <CardTitle className="text-2xl text-gray-900">Atos por Ano</CardTitle>
              <CardDescription>Evolução temporal dos atos executivos</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={stats.atosPorAno}>
                  <CartesianGrid strokeDasharray="3 3" stroke={PALETA_CORES.confinsCeu} />
                  <XAxis dataKey="ano" tick={{ fill: PALETA_CORES.indigo }} />
                  <YAxis tick={{ fill: PALETA_CORES.indigo }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: `2px solid ${PALETA_CORES.confinsCeu}`,
                      borderRadius: '8px'
                    }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="quantidade" 
                    stroke={PALETA_CORES.baiaTodosSantos} 
                    strokeWidth={3}
                    dot={{ fill: PALETA_CORES.baiaTodosSantos, r: 5 }}
                    activeDot={{ r: 8 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Proposições por Data */}
          <Card className="border-0 shadow-lg bg-white">
            <CardHeader className="border-b bg-gray-50">
              <CardTitle className="text-2xl text-gray-900">Proposições Recentes</CardTitle>
              <CardDescription>Últimas proposições por data</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={stats.proposicoesPorData}>
                  <CartesianGrid strokeDasharray="3 3" stroke={PALETA_CORES.confinsCeu} />
                  <XAxis dataKey="data" tick={{ fill: PALETA_CORES.indigo }} />
                  <YAxis tick={{ fill: PALETA_CORES.indigo }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: `2px solid ${PALETA_CORES.confinsCeu}`,
                      borderRadius: '8px'
                    }} 
                  />
                  <Bar dataKey="quantidade" fill={PALETA_CORES.silencioNoite} radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
