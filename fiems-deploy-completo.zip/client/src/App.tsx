import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/DashboardNovo";
import Proposicoes from "./pages/Proposicoes";
import Atos from "./pages/Atos";
import Alertas from "./pages/Alertas";
import ProposicaoDetalhes from "./pages/ProposicaoDetalhes";
import AtoDetalhes from "./pages/AtoDetalhes";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/proposicoes"} component={Proposicoes} />
      <Route path={"/proposicoes/:id"} component={ProposicaoDetalhes} />
      <Route path={"/atos"} component={Atos} />
      <Route path={"/atos/:id"} component={AtoDetalhes} />
      <Route path={"/alertas"} component={Alertas} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
