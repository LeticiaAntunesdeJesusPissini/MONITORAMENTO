import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://ovmyzfdspddexpvpnpjk.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im92bXl6ZmRzcGRkZXhwdnBucGprIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIzNTE5NDcsImV4cCI6MjA3NzkyNzk0N30.4sNVHtKnwHMmRxheIQLuKt4qZfy_nG2wCn3ueQq5nCM';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Tipos para as tabelas
export interface Proposicao {
  id: string;
  numero: string;
  ano: number;
  tipo: string;
  ementa: string;
  autor: string;
  data_apresentacao: string;
  situacao: string;
  tramitacao: string;
  texto_completo?: string;
  url_origem: string;
  classificacao_tematica?: string;
  grau_impacto?: string;
  setores_afetados?: string[];
  status_analise: string;
  sigla?: string;
  numero_real?: string;
  tramitacao_completa?: any;
  resumo_executivo?: string;
  created_at: string;
  updated_at: string;
}

export interface AtoExecutivo {
  id: string;
  numero: string;
  ano: number;
  tipo: string;
  ementa: string;
  orgao_origem: string;
  data_publicacao?: string;
  data_vigencia?: string;
  texto_completo?: string;
  url_doe?: string;
  classificacao_tematica?: string;
  impacto_fiscal?: boolean;
  setores_afetados?: string[];
  status_analise: string;
  resumo_executivo?: string;
  created_at: string;
  updated_at: string;
}

export interface Alerta {
  id: string;
  proposicao_id?: string;
  ato_id?: string;
  tipo_alerta: string;
  prioridade: string;
  mensagem: string;
  lido: boolean;
  created_at: string;
}

export interface AnaliseImpacto {
  id: string;
  proposicao_id?: string;
  ato_executivo_id?: string;
  tipo_documento: string;
  impacto_economico: any;
  impacto_tributario: any;
  impacto_ambiental: any;
  impacto_trabalhista: any;
  impacto_empresarial: any;
  recomendacao_acao: string;
  justificativa: string;
  grau_risco: string;
  grau_oportunidade: string;
  analista_responsavel: string;
  data_analise: string;
  created_at: string;
  updated_at: string;
}

// Nomes reais das tabelas no Supabase
export const TABELA_PROPOSICOES = 'proposicoes_legislativas_2025_11_05_16_31';
export const TABELA_ATOS = 'atos_executivo_2025_11_05_16_31';
export const TABELA_ANALISES = 'analises_impacto_2025_11_05_16_31';
export const TABELA_ALERTAS = 'alertas_2025_11_05_16_31';
