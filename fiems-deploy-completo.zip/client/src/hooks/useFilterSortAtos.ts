import { useState, useMemo, useEffect } from 'react';
import type { AtoExecutivo } from '@/lib/supabase';

export interface FiltrosAtos {
  busca: string;
  tipo: string;
  impacto: string;
  orgao: string;
  classificacao: string;
  dataInicio: string;
  dataFim: string;
}

export type OrdenacaoAtos = 'data-desc' | 'data-asc' | 'numero-asc' | 'numero-desc' | 'impacto-desc' | 'impacto-asc';

const STORAGE_KEY_FILTROS = 'fiems-filtros-atos';
const STORAGE_KEY_ORDENACAO = 'fiems-ordenacao-atos';

export function useFilterSortAtos<T extends AtoExecutivo>(atos: T[]) {
  // Estado dos filtros com persistência
  const [filtros, setFiltros] = useState<FiltrosAtos>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_FILTROS);
    return saved ? JSON.parse(saved) : {
      busca: '',
      tipo: '',
      impacto: '',
      orgao: '',
      classificacao: '',
      dataInicio: '',
      dataFim: '',
    };
  });

  // Estado da ordenação com persistência
  const [ordenacao, setOrdenacao] = useState<OrdenacaoAtos>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_ORDENACAO);
    return (saved as OrdenacaoAtos) || 'data-desc';
  });

  // Persistir filtros no localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_FILTROS, JSON.stringify(filtros));
  }, [filtros]);

  // Persistir ordenação no localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ORDENACAO, ordenacao);
  }, [ordenacao]);

  // Função para atualizar filtros
  const handleFilterChange = (key: keyof FiltrosAtos, value: string) => {
    setFiltros(prev => ({ ...prev, [key]: value }));
  };

  // Função para limpar filtros
  const limparFiltros = () => {
    setFiltros({
      busca: '',
      tipo: '',
      impacto: '',
      orgao: '',
      classificacao: '',
      dataInicio: '',
      dataFim: '',
    });
  };

  // Aplicar filtros
  const atosFiltrados = useMemo(() => {
    return atos.filter(ato => {
      // Busca geral
      if (filtros.busca) {
        const busca = filtros.busca.toLowerCase();
        const match = 
          ato.ementa?.toLowerCase().includes(busca) ||
          ato.orgao_origem?.toLowerCase().includes(busca) ||
          ato.numero?.toLowerCase().includes(busca) ||
          ato.tipo?.toLowerCase().includes(busca);
        if (!match) return false;
      }

      // Filtro por tipo
      if (filtros.tipo && ato.tipo !== filtros.tipo) {
        return false;
      }

      // Filtro por impacto
      if (filtros.impacto) {
        // Buscar análise de impacto associada
        // Por enquanto, usar um campo hipotético
        const impactoAto = (ato as any).grau_impacto || 'Não analisado';
        if (impactoAto !== filtros.impacto) {
          return false;
        }
      }

      // Filtro por órgão
      if (filtros.orgao && ato.orgao_origem !== filtros.orgao) {
        return false;
      }

      // Filtro por classificação temática
      if (filtros.classificacao && ato.classificacao_tematica !== filtros.classificacao) {
        return false;
      }

      // Filtro por período
      if (filtros.dataInicio && ato.data_publicacao) {
        if (new Date(ato.data_publicacao) < new Date(filtros.dataInicio)) {
          return false;
        }
      }
      if (filtros.dataFim && ato.data_publicacao) {
        if (new Date(ato.data_publicacao) > new Date(filtros.dataFim)) {
          return false;
        }
      }

      return true;
    });
  }, [atos, filtros]);

  // Aplicar ordenação
  const atosOrdenados = useMemo(() => {
    const sorted = [...atosFiltrados];

    switch (ordenacao) {
      case 'data-desc':
        return sorted.sort((a, b) => {
          const dateA = a.data_publicacao ? new Date(a.data_publicacao).getTime() : 0;
          const dateB = b.data_publicacao ? new Date(b.data_publicacao).getTime() : 0;
          return dateB - dateA;
        });
      
      case 'data-asc':
        return sorted.sort((a, b) => {
          const dateA = a.data_publicacao ? new Date(a.data_publicacao).getTime() : 0;
          const dateB = b.data_publicacao ? new Date(b.data_publicacao).getTime() : 0;
          return dateA - dateB;
        });
      
      case 'numero-asc':
        return sorted.sort((a, b) => {
          const numA = parseInt(a.numero) || 0;
          const numB = parseInt(b.numero) || 0;
          return numA - numB;
        });
      
      case 'numero-desc':
        return sorted.sort((a, b) => {
          const numA = parseInt(a.numero) || 0;
          const numB = parseInt(b.numero) || 0;
          return numB - numA;
        });
      
      case 'impacto-desc':
        return sorted.sort((a, b) => {
          const impactoOrder = { 'Alto': 3, 'Médio': 2, 'Baixo': 1, 'Não analisado': 0 };
          const impactoA = impactoOrder[(a as any).grau_impacto as keyof typeof impactoOrder] || 0;
          const impactoB = impactoOrder[(b as any).grau_impacto as keyof typeof impactoOrder] || 0;
          return impactoB - impactoA;
        });
      
      case 'impacto-asc':
        return sorted.sort((a, b) => {
          const impactoOrder = { 'Alto': 3, 'Médio': 2, 'Baixo': 1, 'Não analisado': 0 };
          const impactoA = impactoOrder[(a as any).grau_impacto as keyof typeof impactoOrder] || 0;
          const impactoB = impactoOrder[(b as any).grau_impacto as keyof typeof impactoOrder] || 0;
          return impactoA - impactoB;
        });
      
      default:
        return sorted;
    }
  }, [atosFiltrados, ordenacao]);

  // Extrair valores únicos para os dropdowns
  const tiposDisponiveis = useMemo(() => {
    return Array.from(new Set(atos.map(a => a.tipo).filter(Boolean)));
  }, [atos]);

  const orgaosDisponiveis = useMemo(() => {
    return Array.from(new Set(atos.map(a => a.orgao_origem).filter(Boolean)));
  }, [atos]);

  const classificacoesDisponiveis = useMemo(() => {
    return Array.from(new Set(atos.map(a => a.classificacao_tematica).filter(Boolean)));
  }, [atos]);

  return {
    filtros,
    ordenacao,
    atosOrdenados,
    handleFilterChange,
    setOrdenacao,
    limparFiltros,
    tiposDisponiveis,
    orgaosDisponiveis,
    classificacoesDisponiveis,
    totalFiltrados: atosOrdenados.length,
    totalOriginal: atos.length,
  };
}
