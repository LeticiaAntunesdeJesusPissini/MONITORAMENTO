import { useMemo } from 'react';
import type { FilterOptions, SortOptions } from '@/components/FilterBar';

interface FilterableItem {
  tipo: string;
  grau_impacto?: string;
  situacao?: string;
  data_apresentacao?: string;
  data_publicacao?: string;
  autor?: string;
  orgao_origem?: string;
  classificacao_tematica?: string;
  ementa?: string;
  numero?: string;
  sigla?: string;
  numero_real?: string;
  [key: string]: any;
}

/**
 * Hook customizado para filtrar e ordenar listas de proposições/atos
 */
export function useFilterSort<T extends FilterableItem>(
  items: T[],
  filters: FilterOptions,
  sort: SortOptions
): T[] {
  return useMemo(() => {
    let resultado = [...items];

    // Aplicar filtros
    if (filters.tipo) {
      resultado = resultado.filter(item => 
        item.tipo?.toLowerCase().includes(filters.tipo!.toLowerCase())
      );
    }

    if (filters.impacto) {
      resultado = resultado.filter(item => 
        item.grau_impacto?.toLowerCase() === filters.impacto!.toLowerCase()
      );
    }

    if (filters.status) {
      resultado = resultado.filter(item => 
        item.situacao?.toLowerCase().includes(filters.status!.toLowerCase())
      );
    }

    if (filters.autor) {
      resultado = resultado.filter(item => 
        item.autor?.toLowerCase().includes(filters.autor!.toLowerCase()) ||
        item.orgao_origem?.toLowerCase().includes(filters.autor!.toLowerCase())
      );
    }

    if (filters.classificacao) {
      resultado = resultado.filter(item => 
        item.classificacao_tematica?.toLowerCase().includes(filters.classificacao!.toLowerCase())
      );
    }

    if (filters.busca) {
      const busca = filters.busca.toLowerCase();
      resultado = resultado.filter(item => 
        item.ementa?.toLowerCase().includes(busca) ||
        item.tipo?.toLowerCase().includes(busca) ||
        item.autor?.toLowerCase().includes(busca) ||
        item.orgao_origem?.toLowerCase().includes(busca) ||
        item.numero?.toLowerCase().includes(busca) ||
        item.sigla?.toLowerCase().includes(busca) ||
        item.numero_real?.toLowerCase().includes(busca) ||
        item.classificacao_tematica?.toLowerCase().includes(busca)
      );
    }

    // Filtro por período
    if (filters.dataInicio) {
      const dataInicio = new Date(filters.dataInicio);
      resultado = resultado.filter(item => {
        const dataItem = new Date(item.data_apresentacao || item.data_publicacao || '');
        return dataItem >= dataInicio;
      });
    }

    if (filters.dataFim) {
      const dataFim = new Date(filters.dataFim);
      resultado = resultado.filter(item => {
        const dataItem = new Date(item.data_apresentacao || item.data_publicacao || '');
        return dataItem <= dataFim;
      });
    }

    // Aplicar ordenação
    resultado.sort((a, b) => {
      let comparacao = 0;

      switch (sort.campo) {
        case 'data': {
          const dataA = new Date(a.data_apresentacao || a.data_publicacao || '');
          const dataB = new Date(b.data_apresentacao || b.data_publicacao || '');
          comparacao = dataA.getTime() - dataB.getTime();
          break;
        }

        case 'sigla': {
          const siglaA = a.sigla || a.numero || '';
          const siglaB = b.sigla || b.numero || '';
          comparacao = siglaA.localeCompare(siglaB);
          break;
        }

        case 'numero': {
          const numA = parseInt(a.numero_real || a.numero || '0');
          const numB = parseInt(b.numero_real || b.numero || '0');
          comparacao = numA - numB;
          break;
        }

        case 'impacto': {
          const impactoOrdem: Record<string, number> = {
            'alto': 3,
            'médio': 2,
            'baixo': 1,
            '': 0
          };
          const impactoA = impactoOrdem[a.grau_impacto?.toLowerCase() || ''] || 0;
          const impactoB = impactoOrdem[b.grau_impacto?.toLowerCase() || ''] || 0;
          comparacao = impactoA - impactoB;
          break;
        }

        case 'tipo': {
          comparacao = (a.tipo || '').localeCompare(b.tipo || '');
          break;
        }

        default:
          comparacao = 0;
      }

      // Inverter se ordem descendente
      return sort.ordem === 'desc' ? -comparacao : comparacao;
    });

    return resultado;
  }, [items, filters, sort]);
}

/**
 * Extrai valores únicos de um campo para popular dropdowns
 */
export function extrairValoresUnicos<T extends Record<string, any>>(
  items: T[],
  campo: keyof T
): string[] {
  const valores = items
    .map(item => item[campo])
    .filter(valor => typeof valor === 'string' && valor.length > 0) as string[];
  
  return Array.from(new Set(valores)).sort();
}

/**
 * Salva filtros no localStorage
 */
export function salvarFiltros(chave: string, filters: FilterOptions): void {
  try {
    localStorage.setItem(`filtros_${chave}`, JSON.stringify(filters));
  } catch (error) {
    console.error('Erro ao salvar filtros:', error);
  }
}

/**
 * Carrega filtros do localStorage
 */
export function carregarFiltros(chave: string): FilterOptions {
  try {
    const salvos = localStorage.getItem(`filtros_${chave}`);
    return salvos ? JSON.parse(salvos) : {};
  } catch (error) {
    console.error('Erro ao carregar filtros:', error);
    return {};
  }
}

/**
 * Salva ordenação no localStorage
 */
export function salvarOrdenacao(chave: string, sort: SortOptions): void {
  try {
    localStorage.setItem(`ordenacao_${chave}`, JSON.stringify(sort));
  } catch (error) {
    console.error('Erro ao salvar ordenação:', error);
  }
}

/**
 * Carrega ordenação do localStorage
 */
export function carregarOrdenacao(chave: string): SortOptions | null {
  try {
    const salvos = localStorage.getItem(`ordenacao_${chave}`);
    return salvos ? JSON.parse(salvos) : null;
  } catch (error) {
    console.error('Erro ao carregar ordenação:', error);
    return null;
  }
}
