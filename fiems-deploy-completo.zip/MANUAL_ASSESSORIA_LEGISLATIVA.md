# 📖 Manual do Sistema de Monitoramento Legislativo FIEMS

**Versão 1.0 - Novembro 2025**

---

## 🎯 Visão Geral

O Sistema de Monitoramento Legislativo FIEMS é uma ferramenta avançada que utiliza inteligência artificial para coletar, analisar e classificar automaticamente proposições legislativas da ALEMS e atos do executivo publicados no DOE/MS, com foco no impacto para o setor industrial de Mato Grosso do Sul.

---

## 📊 Dados Atuais do Sistema

### Documentos Monitorados

- ✅ **44 Proposições Legislativas** (ALEMS - 04-05/11/2025)
- ✅ **25 Atos do Executivo** (DOE/MS - 2003-2025)
- ✅ **69 Documentos Totais** (100% reais e verificáveis)

### Análises de Impacto

- ✅ **69 análises completas** geradas por IA
- ✅ **Classificação temática** em 10 categorias
- ✅ **Grau de impacto** (Alto, Médio, Baixo)
- ✅ **Recomendações de ação** específicas

### Deputados Identificados

- ✅ **12 deputados** com proposições monitoradas
- ✅ Autoria completa de cada documento

---

## 🚀 Como Usar o Sistema

### 1. Página Inicial (Home)

**Acesso**: https://[seu-dominio]

**Funcionalidades**:
- Visão geral dos documentos monitorados
- Cards de acesso rápido às seções principais
- Estatísticas atualizadas em tempo real

**Cards Disponíveis**:
1. **Proposições ALEMS** - Ver todas as proposições legislativas
2. **Atos do Executivo** - Ver decretos, portarias e resoluções
3. **Alertas Prioritários** - Documentos de alto impacto

---

### 2. Proposições Legislativas

**Acesso**: Home → "Ver Proposições"

**O que você vê**:
- **Lista completa** das 44 proposições
- **Resumo Executivo** destacado em cada card:
  - 🟡 **Impacto Alto**: Fundo amarelo, requer atenção imediata
  - 🔵 **Impacto Médio**: Fundo azul claro, monitoramento recomendado
  - 🟢 **Impacto Baixo**: Fundo verde claro, monitoramento informativo

**Informações nos Cards**:
- Tipo e ano da proposição
- Classificação temática (Infraestrutura, Tributário, etc.)
- Grau de impacto
- Ementa completa
- Autor e data de apresentação
- Status atual

**Busca e Filtros**:
- Campo de busca por palavra-chave, autor ou tema
- Filtros por classificação temática
- Filtros por grau de impacto

---

### 3. Página Individual de Proposição

**Acesso**: Clicar em qualquer proposição da lista

**RESUMO EXECUTIVO (Topo da Página)**:
- ✅ **Recomendação de Ação** - O que a FIEMS deve fazer
- 📊 **Impacto Tributário** - Nível de impacto fiscal
- 🏭 **Impacto Empresarial** - Nível de impacto no setor
- ⚠️ **Grau de Risco** - Avaliação de riscos

**Seções Disponíveis**:
1. **Ementa** - Texto oficial da proposição
2. **Tramitação** - Histórico de movimentação (quando disponível)
3. **Status** - Situação atual
4. **Grau de Impacto** - Classificação (Alto/Médio/Baixo)
5. **Classificação** - Categoria temática
6. **Análise de Impacto Completa** - Detalhamento de todos os impactos

---

### 4. Atos do Executivo

**Acesso**: Home → "Ver Atos"

**O que você vê**:
- **Lista completa** dos 25 atos
- **Resumo Executivo** destacado (quando há impacto fiscal)
- Decretos, portarias e resoluções organizados por data

**Informações nos Cards**:
- Tipo, número e ano do ato
- Órgão de origem
- Ementa completa
- Data de publicação
- Link para DOE/MS

**Destaques**:
- 🟡 **Atos com Impacto Fiscal**: Fundo amarelo, atenção especial
- 🔵 **Atos Normativos**: Fundo azul claro, verificação recomendada

---

### 5. Alertas Prioritários

**Acesso**: Home → "Ver Alertas"

**O que você vê**:
- **30 alertas** organizados por prioridade
- **6 Alta Prioridade** - Proposições de alto impacto
- **10 Média Prioridade** - Proposições recentes (últimos 7 dias)
- **14 Baixa Prioridade** - Atos de 2024-2025

**Como usar**:
1. Foque primeiro nos alertas de **Alta Prioridade**
2. Revise os de **Média Prioridade** semanalmente
3. Monitore os de **Baixa Prioridade** mensalmente

---

### 6. Dashboard Analítico

**Acesso**: Home → "Acessar Dashboard Completo"

**Gráficos Disponíveis**:
1. **Proposições por Classificação** - Distribuição temática
2. **Grau de Impacto** - Quantidade por nível
3. **Atos por Tipo** - Decretos, portarias, etc.
4. **Linha do Tempo** - Evolução temporal

**Estatísticas**:
- Total de documentos monitorados
- Documentos de alto impacto
- Documentos recentes (últimos 30 dias)

---

## 🎨 Entendendo as Cores

### Paleta Sherwin-Williams

O sistema usa uma paleta profissional de cores para facilitar a identificação:

- **Índigo (#1F3A5F)**: Títulos principais
- **Jacarandá-mimoso (#7FA8C4)**: Botões e destaques
- **Baía de Todos-os-santos (#2B5F75)**: Badges de classificação
- **Confins do Céu (#C4D7E0)**: Fundos de cards
- **Orvalho das Estrelas (#A8B5B2)**: Elementos secundários

### Cores de Impacto

- 🟡 **Amarelo (#fef3c7)**: Alto impacto - ATENÇÃO
- 🔵 **Azul (#dbeafe)**: Médio impacto - MONITORAR
- 🟢 **Verde (#f0fdf4)**: Baixo impacto - INFORMATIVO

---

## 📋 Interpretando as Análises da IA

### Recomendações de Ação

**MONITORAMENTO ATIVO**:
- Proposição/ato requer acompanhamento próximo
- Avaliar necessidade de posicionamento da FIEMS
- Verificar tramitação regularmente

**ANÁLISE JURÍDICA NECESSÁRIA**:
- Ato com impacto fiscal/tributário
- Requer avaliação técnica especializada
- Possível impacto direto no setor empresarial

**MONITORAMENTO INFORMATIVO**:
- Baixo impacto direto
- Acompanhamento periódico suficiente

### Níveis de Impacto

**ALTO**:
- Impacto direto e significativo no setor industrial
- Pode afetar custos, operações ou regulamentação
- Requer posicionamento da FIEMS

**MÉDIO**:
- Impacto moderado ou indireto
- Pode afetar setores específicos
- Monitoramento recomendado

**BAIXO**:
- Impacto mínimo ou muito indireto
- Monitoramento informativo

---

## 🔍 Verificando a Autenticidade dos Dados

### Proposições Legislativas

**Fonte**: Sistema de Gestão de Proposições Legislativas (SGPL) da ALEMS

**Como verificar**:
1. Clique no botão "Ver no SGPL" em qualquer proposição
2. Você será redirecionado para o site oficial da ALEMS
3. Verifique o número, autor e ementa

**URL oficial**: https://sgpl.consulta.al.ms.gov.br/sgpl-publico/

### Atos do Executivo

**Fonte**: Diário Oficial Eletrônico de Mato Grosso do Sul (DOE/MS)

**Como verificar**:
1. Clique no botão "Ver no DOE" em qualquer ato
2. Você será redirecionado para o DOE/MS
3. Verifique o número, data e conteúdo

**URL oficial**: https://www.diariooficial.ms.gov.br/

---

## ⚙️ Atualizando os Dados

### Coleta Automática (Futura)

O sistema está preparado para coleta automática periódica. Para implementar:

1. Configurar script de coleta no servidor
2. Agendar execução diária (recomendado: 8h00)
3. Notificações automáticas para documentos de alto impacto

### Coleta Manual (Atual)

Para adicionar novos documentos manualmente:

1. Acesse o Supabase (banco de dados)
2. Use os scripts em `/scripts/`
3. Execute `gerar_analises_ia.py` para análises automáticas

**Contato técnico**: [inserir contato da equipe técnica]

---

## 📞 Suporte e Contato

### Problemas Técnicos

- **Email**: [inserir email de suporte]
- **Telefone**: [inserir telefone]

### Sugestões de Melhoria

- **Email**: [inserir email]
- **Formulário**: [inserir link]

### Documentação Técnica

- **Repositório**: /home/ubuntu/sistema-monitoramento-fiems/
- **Scripts**: /scripts/
- **Dados**: Supabase (banco de dados em nuvem)

---

## 📚 Glossário

**ALEMS**: Assembleia Legislativa de Mato Grosso do Sul

**DOE/MS**: Diário Oficial Eletrônico de Mato Grosso do Sul

**SGPL**: Sistema de Gestão de Proposições Legislativas

**FIEMS**: Federação das Indústrias de Mato Grosso do Sul

**Ementa**: Resumo oficial do conteúdo de uma proposição ou ato

**Tramitação**: Processo de movimentação de uma proposição nas comissões e plenário

**Grau de Impacto**: Classificação do nível de impacto para o setor industrial (Alto, Médio, Baixo)

**Classificação Temática**: Categoria do documento (Infraestrutura, Tributário, Ambiental, etc.)

---

## 🎓 Boas Práticas de Uso

### Rotina Diária

1. **Manhã (8h-9h)**:
   - Verificar Alertas Prioritários
   - Revisar proposições de Alto Impacto
   - Ler Resumos Executivos

2. **Tarde (14h-15h)**:
   - Verificar novos atos do DOE/MS
   - Atualizar planilhas de acompanhamento
   - Preparar briefings para diretoria

### Rotina Semanal

1. **Segunda-feira**:
   - Revisar todas as proposições da semana anterior
   - Verificar tramitação de proposições em acompanhamento

2. **Sexta-feira**:
   - Gerar relatório semanal
   - Identificar proposições que requerem posicionamento
   - Planejar ações para semana seguinte

### Rotina Mensal

1. **Primeira semana**:
   - Análise estatística do Dashboard
   - Identificar tendências legislativas
   - Preparar relatório mensal para diretoria

---

## ✅ Checklist de Verificação

### Antes de Posicionar a FIEMS

- [ ] Verificar autenticidade no SGPL/DOE
- [ ] Ler ementa completa
- [ ] Revisar análise de impacto da IA
- [ ] Consultar área técnica (jurídica, tributária, etc.)
- [ ] Verificar tramitação atual
- [ ] Identificar prazos para manifestação
- [ ] Avaliar impacto em outros setores
- [ ] Consultar entidades parceiras (se aplicável)

---

## 📊 Indicadores de Desempenho

### Métricas Sugeridas

1. **Tempo de Resposta**: Tempo entre identificação e posicionamento
2. **Taxa de Acerto**: Proposições corretamente classificadas como alto impacto
3. **Cobertura**: % de proposições relevantes monitoradas
4. **Efetividade**: % de posicionamentos que influenciaram tramitação

---

## 🔐 Segurança e Privacidade

### Dados Públicos

- Todos os documentos são de domínio público
- Fontes oficiais (ALEMS e DOE/MS)
- Nenhum dado sensível ou privado

### Análises da IA

- Análises são geradas automaticamente
- Baseadas em classificação temática e conteúdo
- Não substituem análise humana especializada
- Servem como apoio à decisão

---

## 📅 Histórico de Versões

### v1.0 - Novembro 2025

- ✅ Coleta de 44 proposições (04-05/11/2025)
- ✅ Coleta de 25 atos do executivo
- ✅ Análises de impacto com IA
- ✅ Resumos executivos visíveis
- ✅ Dashboard analítico
- ✅ Sistema de alertas prioritários
- ✅ Paleta de cores Sherwin-Williams
- ✅ Interface otimizada para Assessoria

---

## 🎯 Próximos Passos (Roadmap)

### Curto Prazo (1-2 meses)

- [ ] Coleta automática diária
- [ ] Notificações por email
- [ ] Exportação de relatórios em PDF
- [ ] Integração com sistema de protocolo

### Médio Prazo (3-6 meses)

- [ ] Análise de sentimento em redes sociais
- [ ] Previsão de tramitação com IA
- [ ] Dashboard personalizado por usuário
- [ ] App mobile

### Longo Prazo (6-12 meses)

- [ ] Integração com outros estados
- [ ] Análise comparativa regional
- [ ] Sistema de recomendação de ações
- [ ] Plataforma colaborativa com outras entidades

---

**Sistema de Monitoramento Legislativo FIEMS © 2025**

*Desenvolvido com tecnologia avançada para apoiar a Assessoria Legislativa da FIEMS no acompanhamento eficiente da atividade legislativa e regulatória de Mato Grosso do Sul.*

---

**Última atualização**: 06 de novembro de 2025
