import { createClient } from '@supabase/supabase-js';
import fs from 'fs';

const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://iqjxqvxlqcbxgbkpbwhe.supabase.co';
const supabaseKey = process.env.SUPABASE_KEY || process.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseKey) {
  console.error('❌ SUPABASE_KEY não configurada');
  console.log('\n📝 Para inserir os dados, você precisa:');
  console.log('1. Obter a chave do Supabase no painel de administração');
  console.log('2. Exportar: export SUPABASE_KEY="sua_chave_aqui"');
  console.log('3. Executar novamente: node inserir-novas-proposicoes.mjs\n');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

// Dados das proposições
const proposicoes = [
  {
    tipo: 'Projeto de Lei',
    numero: '281',
    ano: '2025',
    data_apresentacao: '2025-11-05',
    autor: 'Poder Executivo',
    ementa: 'Autoriza o Poder Executivo Estadual a contratar operação de crédito com o Banco do Brasil S.A., com garantia da União, no valor de até R$ 950 milhões, destinado a projetos estratégicos de investimentos, com foco no desenvolvimento social e econômico de Mato Grosso do Sul.',
    situacao: 'Em tramitação',
    classificacao_tematica: JSON.stringify(['Financeiro', 'Infraestrutura', 'Desenvolvimento Econômico']),
    grau_impacto: 'Alto',
    tramitacao: 'Regime de urgência. 05/11: Recebido. 11/11: CCJR e 1ª discussão. 12/11: 2ª discussão e redação final.'
  },
  {
    tipo: 'Projeto de Decreto Legislativo',
    numero: '015',
    ano: '2025',
    data_apresentacao: '2025-11-06',
    autor: 'Mesa Diretora (2025-2026)',
    ementa: 'Ratifica os Convênios ICMS, Ajustes SINIEF e Protocolo ICMS, celebrados no âmbito do Conselho Nacional de Política Fazendária (CONFAZ), nos termos da Mensagem n. 35/2025 do Governo do Estado, de 3 de novembro de 2025. Aprova 39 Convênios ICMS, 19 Ajustes SINIEF e 2 Protocolos ICMS.',
    situacao: 'Em tramitação',
    classificacao_tematica: JSON.stringify(['Tributário', 'Fiscal', 'ICMS', 'CONFAZ']),
    grau_impacto: 'Alto',
    tramitacao: '06/11: Lido em plenário. Segue para CCJR.'
  }
];

// Análises
const analises = JSON.parse(fs.readFileSync('/home/ubuntu/analises_novas_proposicoes.json', 'utf-8'));

async function inserirProposicoes() {
  console.log('🔄 Iniciando inserção de proposições...\n');
  
  for (let i = 0; i < proposicoes.length; i++) {
    const prop = proposicoes[i];
    const analise = analises[i].analise;
    
    console.log(`📝 Inserindo: ${prop.tipo} ${prop.numero}/${prop.ano}`);
    
    // Inserir proposição
    const { data: propData, error: propError } = await supabase
      .from('proposicoes_legislativas_2025_11_05_16_31')
      .insert(prop)
      .select()
      .single();
    
    if (propError) {
      console.error(`   ❌ Erro ao inserir proposição: ${propError.message}`);
      continue;
    }
    
    console.log(`   ✅ Proposição inserida (ID: ${propData.id})`);
    
    // Inserir análise
    const analiseData = {
      proposicao_id: propData.id,
      resumo_executivo: analise.resumo_executivo,
      recomendacao_acao: analise.recomendacao_acao,
      impacto_tributario: analise.impacto_tributario,
      impacto_empresarial: analise.impacto_empresarial,
      grau_risco: analise.grau_risco,
      grau_oportunidade: analise.grau_oportunidade
    };
    
    const { error: analiseError } = await supabase
      .from('analises_proposicoes_2025_11_05_16_31')
      .insert(analiseData);
    
    if (analiseError) {
      console.error(`   ❌ Erro ao inserir análise: ${analiseError.message}`);
    } else {
      console.log(`   ✅ Análise inserida\n`);
    }
  }
  
  console.log('✅ Inserção concluída!');
}

inserirProposicoes().catch(console.error);
